package org.apache.regexp;

public class RESyntaxException
  extends RuntimeException
{
  public RESyntaxException(String paramString)
  {
    super("Syntax error: " + paramString);
  }
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/jakarta-regexp-1.5.jar!/org/apache/regexp/RESyntaxException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */