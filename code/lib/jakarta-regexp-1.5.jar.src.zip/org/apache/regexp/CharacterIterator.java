package org.apache.regexp;

public abstract interface CharacterIterator
{
  public abstract String substring(int paramInt1, int paramInt2);
  
  public abstract String substring(int paramInt);
  
  public abstract char charAt(int paramInt);
  
  public abstract boolean isEnd(int paramInt);
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/jakarta-regexp-1.5.jar!/org/apache/regexp/CharacterIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */