package org.apache.regexp;

import java.util.Hashtable;

public class RECompiler
{
  char[] instruction = new char[''];
  int lenInstruction = 0;
  String pattern;
  int len;
  int idx;
  int parens;
  static final int NODE_NORMAL = 0;
  static final int NODE_NULLABLE = 1;
  static final int NODE_TOPLEVEL = 2;
  static final int ESC_MASK = 1048560;
  static final int ESC_BACKREF = 1048575;
  static final int ESC_COMPLEX = 1048574;
  static final int ESC_CLASS = 1048573;
  static final int bracketUnbounded = -1;
  int bracketMin;
  int bracketOpt;
  static final Hashtable hashPOSIX = new Hashtable();
  
  void ensure(int paramInt)
  {
    int i = this.instruction.length;
    if (this.lenInstruction + paramInt >= i)
    {
      while (this.lenInstruction + paramInt >= i) {
        i *= 2;
      }
      char[] arrayOfChar = new char[i];
      System.arraycopy(this.instruction, 0, arrayOfChar, 0, this.lenInstruction);
      this.instruction = arrayOfChar;
    }
  }
  
  void emit(char paramChar)
  {
    ensure(1);
    this.instruction[(this.lenInstruction++)] = paramChar;
  }
  
  void nodeInsert(char paramChar, int paramInt1, int paramInt2)
  {
    ensure(3);
    System.arraycopy(this.instruction, paramInt2, this.instruction, paramInt2 + 3, this.lenInstruction - paramInt2);
    this.instruction[paramInt2] = paramChar;
    this.instruction[(paramInt2 + 1)] = ((char)paramInt1);
    this.instruction[(paramInt2 + 2)] = '\000';
    this.lenInstruction += 3;
  }
  
  void setNextOfEnd(int paramInt1, int paramInt2)
  {
    for (int i = this.instruction[(paramInt1 + 2)]; (i != 0) && (paramInt1 < this.lenInstruction); i = this.instruction[(paramInt1 + 2)])
    {
      if (paramInt1 == paramInt2) {
        paramInt2 = this.lenInstruction;
      }
      paramInt1 += i;
    }
    if (paramInt1 < this.lenInstruction)
    {
      int j = paramInt2 - paramInt1;
      if (j != (short)j) {
        throw new RESyntaxException("Exceeded short jump range.");
      }
      this.instruction[(paramInt1 + 2)] = ((char)(short)j);
    }
  }
  
  int node(char paramChar, int paramInt)
  {
    ensure(3);
    this.instruction[this.lenInstruction] = paramChar;
    this.instruction[(this.lenInstruction + 1)] = ((char)paramInt);
    this.instruction[(this.lenInstruction + 2)] = '\000';
    this.lenInstruction += 3;
    return this.lenInstruction - 3;
  }
  
  void internalError()
    throws Error
  {
    throw new Error("Internal error!");
  }
  
  void syntaxError(String paramString)
    throws RESyntaxException
  {
    throw new RESyntaxException(paramString);
  }
  
  void bracket()
    throws RESyntaxException
  {
    if ((this.idx >= this.len) || (this.pattern.charAt(this.idx++) != '{')) {
      internalError();
    }
    if ((this.idx >= this.len) || (!Character.isDigit(this.pattern.charAt(this.idx)))) {
      syntaxError("Expected digit");
    }
    StringBuffer localStringBuffer = new StringBuffer();
    while ((this.idx < this.len) && (Character.isDigit(this.pattern.charAt(this.idx)))) {
      localStringBuffer.append(this.pattern.charAt(this.idx++));
    }
    try
    {
      this.bracketMin = Integer.parseInt(localStringBuffer.toString());
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      syntaxError("Expected valid number");
    }
    if (this.idx >= this.len) {
      syntaxError("Expected comma or right bracket");
    }
    if (this.pattern.charAt(this.idx) == '}')
    {
      this.idx += 1;
      this.bracketOpt = 0;
      return;
    }
    if ((this.idx >= this.len) || (this.pattern.charAt(this.idx++) != ',')) {
      syntaxError("Expected comma");
    }
    if (this.idx >= this.len) {
      syntaxError("Expected comma or right bracket");
    }
    if (this.pattern.charAt(this.idx) == '}')
    {
      this.idx += 1;
      this.bracketOpt = -1;
      return;
    }
    if ((this.idx >= this.len) || (!Character.isDigit(this.pattern.charAt(this.idx)))) {
      syntaxError("Expected digit");
    }
    localStringBuffer.setLength(0);
    while ((this.idx < this.len) && (Character.isDigit(this.pattern.charAt(this.idx)))) {
      localStringBuffer.append(this.pattern.charAt(this.idx++));
    }
    try
    {
      this.bracketOpt = (Integer.parseInt(localStringBuffer.toString()) - this.bracketMin);
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      syntaxError("Expected valid number");
    }
    if (this.bracketOpt < 0) {
      syntaxError("Bad range");
    }
    if ((this.idx >= this.len) || (this.pattern.charAt(this.idx++) != '}')) {
      syntaxError("Missing close brace");
    }
  }
  
  int escape()
    throws RESyntaxException
  {
    if (this.pattern.charAt(this.idx) != '\\') {
      internalError();
    }
    if (this.idx + 1 == this.len) {
      syntaxError("Escape terminates string");
    }
    this.idx += 2;
    char c = this.pattern.charAt(this.idx - 1);
    int i;
    switch (c)
    {
    case 'B': 
    case 'b': 
      return 1048574;
    case 'D': 
    case 'S': 
    case 'W': 
    case 'd': 
    case 's': 
    case 'w': 
      return 1048573;
    case 'u': 
    case 'x': 
      i = c == 'u' ? 4 : 2;
      int j = 0;
      while ((this.idx < this.len) && (i-- > 0))
      {
        int k = this.pattern.charAt(this.idx);
        if ((k >= 48) && (k <= 57))
        {
          j = (j << 4) + k - 48;
        }
        else
        {
          int m = Character.toLowerCase(k);
          if ((m >= 97) && (m <= 102)) {
            j = (j << 4) + (m - 97) + 10;
          } else {
            syntaxError("Expected " + i + " hexadecimal digits after \\" + c);
          }
        }
        this.idx += 1;
      }
      return j;
    case 't': 
      return 9;
    case 'n': 
      return 10;
    case 'r': 
      return 13;
    case 'f': 
      return 12;
    case '0': 
    case '1': 
    case '2': 
    case '3': 
    case '4': 
    case '5': 
    case '6': 
    case '7': 
    case '8': 
    case '9': 
      if (((this.idx < this.len) && (Character.isDigit(this.pattern.charAt(this.idx)))) || (c == '0'))
      {
        i = c - '0';
        if ((this.idx < this.len) && (Character.isDigit(this.pattern.charAt(this.idx))))
        {
          i = (i << 3) + (this.pattern.charAt(this.idx++) - '0');
          if ((this.idx < this.len) && (Character.isDigit(this.pattern.charAt(this.idx)))) {
            i = (i << 3) + (this.pattern.charAt(this.idx++) - '0');
          }
        }
        return i;
      }
      return 1048575;
    }
    return c;
  }
  
  int characterClass()
    throws RESyntaxException
  {
    if (this.pattern.charAt(this.idx) != '[') {
      internalError();
    }
    if ((this.idx + 1 >= this.len) || (this.pattern.charAt(++this.idx) == ']')) {
      syntaxError("Empty or unterminated class");
    }
    if ((this.idx < this.len) && (this.pattern.charAt(this.idx) == ':'))
    {
      this.idx += 1;
      i = this.idx;
      while ((this.idx < this.len) && (this.pattern.charAt(this.idx) >= 'a') && (this.pattern.charAt(this.idx) <= 'z')) {
        this.idx += 1;
      }
      if ((this.idx + 1 < this.len) && (this.pattern.charAt(this.idx) == ':') && (this.pattern.charAt(this.idx + 1) == ']'))
      {
        String str = this.pattern.substring(i, this.idx);
        localCharacter2 = (Character)hashPOSIX.get(str);
        if (localCharacter2 != null)
        {
          this.idx += 2;
          return node('P', localCharacter2.charValue());
        }
        syntaxError("Invalid POSIX character class '" + str + "'");
      }
      syntaxError("Invalid POSIX character class syntax");
    }
    int i = node('[', 0);
    Character localCharacter1 = 65535;
    Character localCharacter2 = localCharacter1;
    boolean bool = true;
    int m = 0;
    int n = this.idx;
    int i1 = 0;
    RERange localRERange = new RERange();
    while ((this.idx < this.len) && (this.pattern.charAt(this.idx) != ']'))
    {
      int k;
      int i2;
      switch (this.pattern.charAt(this.idx))
      {
      case '^': 
        bool = !bool;
        if (this.idx == n) {
          localRERange.include(0, 65535, true);
        }
        this.idx += 1;
        break;
      case '\\': 
        switch (i4 = escape())
        {
        case 1048574: 
        case 1048575: 
          syntaxError("Bad character class");
        case 1048573: 
          if (m != 0) {
            syntaxError("Bad character class");
          }
          switch (this.pattern.charAt(this.idx - 1))
          {
          case 'S': 
            localRERange.include(0, 7, bool);
            localRERange.include('\013', bool);
            localRERange.include(14, 31, bool);
            localRERange.include(33, 65535, bool);
            break;
          case 'W': 
            localRERange.include(0, 47, bool);
            localRERange.include(58, 64, bool);
            localRERange.include(91, 94, bool);
            localRERange.include('`', bool);
            localRERange.include(123, 65535, bool);
            break;
          case 'D': 
            localRERange.include(0, 47, bool);
            localRERange.include(58, 65535, bool);
            break;
          case 's': 
            localRERange.include('\t', bool);
            localRERange.include('\r', bool);
            localRERange.include('\f', bool);
            localRERange.include('\n', bool);
            localRERange.include('\b', bool);
            localRERange.include(' ', bool);
            break;
          case 'w': 
            localRERange.include(97, 122, bool);
            localRERange.include(65, 90, bool);
            localRERange.include('_', bool);
          case 'd': 
            localRERange.include(48, 57, bool);
          }
          localCharacter2 = localCharacter1;
          break;
        default: 
          k = (char)i4;
        }
        break;
      case '-': 
        if (m != 0) {
          syntaxError("Bad class range");
        }
        m = 1;
        i2 = localCharacter2 == localCharacter1 ? 0 : localCharacter2;
        if ((this.idx + 1 >= this.len) || (this.pattern.charAt(++this.idx) != ']')) {
          continue;
        }
        k = 65535;
        break;
      default: 
        k = this.pattern.charAt(this.idx++);
      }
      int j;
      if (m != 0)
      {
        int i3 = k;
        if (i2 >= i3) {
          syntaxError("Bad character class");
        }
        localRERange.include(i2, i3, bool);
        j = localCharacter1;
        m = 0;
      }
      else
      {
        if ((this.idx >= this.len) || (this.pattern.charAt(this.idx) != '-')) {
          localRERange.include(k, bool);
        }
        j = k;
      }
    }
    if (this.idx == this.len) {
      syntaxError("Unterminated character class");
    }
    this.idx += 1;
    this.instruction[(i + 1)] = ((char)localRERange.num);
    for (int i4 = 0; i4 < localRERange.num; i4++)
    {
      emit((char)localRERange.minRange[i4]);
      emit((char)localRERange.maxRange[i4]);
    }
    return i;
  }
  
  int atom()
    throws RESyntaxException
  {
    int i = node('A', 0);
    int j = 0;
    while (this.idx < this.len)
    {
      int k;
      int m;
      if (this.idx + 1 < this.len)
      {
        k = this.pattern.charAt(this.idx + 1);
        if (this.pattern.charAt(this.idx) == '\\')
        {
          m = this.idx;
          escape();
          if (this.idx < this.len) {
            k = this.pattern.charAt(this.idx);
          }
          this.idx = m;
        }
        switch (k)
        {
        case 42: 
        case 43: 
        case 63: 
        case 123: 
          if (j != 0) {
            break;
          }
        }
      }
      switch (this.pattern.charAt(this.idx))
      {
      case '$': 
      case '(': 
      case ')': 
      case '.': 
      case '[': 
      case ']': 
      case '^': 
      case '|': 
        break;
      case '*': 
      case '+': 
      case '?': 
      case '{': 
        if (j != 0) {
          break label366;
        }
        syntaxError("Missing operand to closure");
        break;
      case '\\': 
        k = this.idx;
        m = escape();
        if ((m & 0xFFFF0) == 1048560)
        {
          this.idx = k;
          break label366;
        }
        emit((char)m);
        j++;
        break;
      default: 
        emit(this.pattern.charAt(this.idx++));
        j++;
      }
    }
    label366:
    if (j == 0) {
      internalError();
    }
    this.instruction[(i + 1)] = ((char)j);
    return i;
  }
  
  int terminal(int[] paramArrayOfInt)
    throws RESyntaxException
  {
    switch (this.pattern.charAt(this.idx))
    {
    case '$': 
    case '.': 
    case '^': 
      return node(this.pattern.charAt(this.idx++), 0);
    case '[': 
      return characterClass();
    case '(': 
      return expr(paramArrayOfInt);
    case ')': 
      syntaxError("Unexpected close paren");
    case '|': 
      internalError();
    case ']': 
      syntaxError("Mismatched class");
    case '\000': 
      syntaxError("Unexpected end of input");
    case '*': 
    case '+': 
    case '?': 
    case '{': 
      syntaxError("Missing operand to closure");
    case '\\': 
      int i = this.idx;
      switch (escape())
      {
      case 1048573: 
      case 1048574: 
        paramArrayOfInt[0] &= 0xFFFFFFFE;
        return node('\\', this.pattern.charAt(this.idx - 1));
      case 1048575: 
        int j = (char)(this.pattern.charAt(this.idx - 1) - '0');
        if (this.parens <= j) {
          syntaxError("Bad backreference");
        }
        paramArrayOfInt[0] |= 0x1;
        return node('#', j);
      }
      this.idx = i;
      paramArrayOfInt[0] &= 0xFFFFFFFE;
    }
    paramArrayOfInt[0] &= 0xFFFFFFFE;
    return atom();
  }
  
  int closure(int[] paramArrayOfInt)
    throws RESyntaxException
  {
    int i = this.idx;
    int[] arrayOfInt1 = { 0 };
    int j = terminal(arrayOfInt1);
    paramArrayOfInt[0] |= arrayOfInt1[0];
    if (this.idx >= this.len) {
      return j;
    }
    int k = 1;
    int m = this.pattern.charAt(this.idx);
    switch (m)
    {
    case 42: 
    case 63: 
      paramArrayOfInt[0] |= 0x1;
    case 43: 
      this.idx += 1;
    case 123: 
      int n = this.instruction[j];
      if ((n == 94) || (n == 36)) {
        syntaxError("Bad closure operand");
      }
      if ((arrayOfInt1[0] & 0x1) != 0) {
        syntaxError("Closure operand can't be nullable");
      }
      break;
    }
    if ((this.idx < this.len) && (this.pattern.charAt(this.idx) == '?'))
    {
      this.idx += 1;
      k = 0;
    }
    int i1;
    if (k != 0) {
      switch (m)
      {
      case 123: 
        bracket();
        i1 = this.idx;
        int i2 = this.bracketMin;
        int i3 = this.bracketOpt;
        int i4 = j;
        for (int i5 = 0; i5 < i2; i5++)
        {
          this.idx = i;
          setNextOfEnd(i4, i4 = terminal(arrayOfInt1));
        }
        if (i3 == -1)
        {
          this.idx = i1;
          nodeInsert('*', 0, i4);
          setNextOfEnd(i4 + 3, i4);
        }
        else
        {
          if (i3 > 0)
          {
            int[] arrayOfInt2 = new int[i3 + 1];
            nodeInsert('?', 0, i4);
            arrayOfInt2[0] = i4;
            for (int i6 = 1; i6 < i3; i6++)
            {
              arrayOfInt2[i6] = node('?', 0);
              this.idx = i;
              terminal(arrayOfInt1);
            }
            int i7 = arrayOfInt2[i3] = node('N', 0);
            for (int i8 = 0; i8 < i3; i8++)
            {
              setNextOfEnd(arrayOfInt2[i8], i7);
              setNextOfEnd(arrayOfInt2[i8] + 3, arrayOfInt2[(i8 + 1)]);
            }
          }
          else
          {
            this.lenInstruction = i4;
            node('N', 0);
          }
          this.idx = i1;
        }
        break;
      case 63: 
        nodeInsert('?', 0, j);
        i1 = node('N', 0);
        setNextOfEnd(j, i1);
        setNextOfEnd(j + 3, i1);
        break;
      case 42: 
        nodeInsert('*', 0, j);
        setNextOfEnd(j + 3, j);
        break;
      case 43: 
        nodeInsert('C', 0, j);
        i1 = node('+', 0);
        setNextOfEnd(j + 3, i1);
        setNextOfEnd(i1, j);
      }
    } else {
      switch (m)
      {
      case 63: 
        nodeInsert('/', 0, j);
        i1 = node('N', 0);
        setNextOfEnd(j, i1);
        setNextOfEnd(j + 3, i1);
        break;
      case 42: 
        nodeInsert('8', 0, j);
        setNextOfEnd(j + 3, j);
        break;
      case 43: 
        nodeInsert('C', 0, j);
        i1 = node('=', 0);
        setNextOfEnd(i1, j);
        setNextOfEnd(j + 3, i1);
      }
    }
    return j;
  }
  
  int branch(int[] paramArrayOfInt)
    throws RESyntaxException
  {
    int j = -1;
    int k = -1;
    int[] arrayOfInt = new int[1];
    int m = 1;
    while ((this.idx < this.len) && (this.pattern.charAt(this.idx) != '|') && (this.pattern.charAt(this.idx) != ')'))
    {
      arrayOfInt[0] = 0;
      int i = closure(arrayOfInt);
      if (arrayOfInt[0] == 0) {
        m = 0;
      }
      if (k != -1) {
        setNextOfEnd(k, i);
      }
      k = i;
      if (j == -1) {
        j = i;
      }
    }
    if (j == -1) {
      j = node('N', 0);
    }
    if (m != 0) {
      paramArrayOfInt[0] |= 0x1;
    }
    return j;
  }
  
  int expr(int[] paramArrayOfInt)
    throws RESyntaxException
  {
    int i = -1;
    int j = -1;
    int k = this.parens;
    if (((paramArrayOfInt[0] & 0x2) == 0) && (this.pattern.charAt(this.idx) == '(')) {
      if ((this.idx + 2 < this.len) && (this.pattern.charAt(this.idx + 1) == '?') && (this.pattern.charAt(this.idx + 2) == ':'))
      {
        i = 2;
        this.idx += 3;
        j = node('<', 0);
      }
      else
      {
        i = 1;
        this.idx += 1;
        j = node('(', this.parens++);
      }
    }
    paramArrayOfInt[0] &= 0xFFFFFFFD;
    int m = 0;
    int n = branch(paramArrayOfInt);
    if (j == -1) {
      j = n;
    } else {
      setNextOfEnd(j, n);
    }
    while ((this.idx < this.len) && (this.pattern.charAt(this.idx) == '|'))
    {
      if (m == 0)
      {
        nodeInsert('|', 0, n);
        m = 1;
      }
      this.idx += 1;
      setNextOfEnd(n, n = node('|', 0));
      branch(paramArrayOfInt);
    }
    int i1;
    if (i > 0)
    {
      if ((this.idx < this.len) && (this.pattern.charAt(this.idx) == ')')) {
        this.idx += 1;
      } else {
        syntaxError("Missing close paren");
      }
      if (i == 1) {
        i1 = node(')', k);
      } else {
        i1 = node('>', 0);
      }
    }
    else
    {
      i1 = node('E', 0);
    }
    setNextOfEnd(j, i1);
    int i2 = j;
    int i3 = this.instruction[(i2 + 2)];
    while ((i3 != 0) && (i2 < this.lenInstruction))
    {
      if (this.instruction[i2] == '|') {
        setNextOfEnd(i2 + 3, i1);
      }
      i3 = this.instruction[(i2 + 2)];
      i2 += i3;
    }
    return j;
  }
  
  public REProgram compile(String paramString)
    throws RESyntaxException
  {
    this.pattern = paramString;
    this.len = paramString.length();
    this.idx = 0;
    this.lenInstruction = 0;
    this.parens = 1;
    int[] arrayOfInt = { 2 };
    expr(arrayOfInt);
    if (this.idx != this.len)
    {
      if (paramString.charAt(this.idx) == ')') {
        syntaxError("Unmatched close paren");
      }
      syntaxError("Unexpected input remains");
    }
    char[] arrayOfChar = new char[this.lenInstruction];
    System.arraycopy(this.instruction, 0, arrayOfChar, 0, this.lenInstruction);
    return new REProgram(this.parens, arrayOfChar);
  }
  
  static
  {
    hashPOSIX.put("alnum", new Character('w'));
    hashPOSIX.put("alpha", new Character('a'));
    hashPOSIX.put("blank", new Character('b'));
    hashPOSIX.put("cntrl", new Character('c'));
    hashPOSIX.put("digit", new Character('d'));
    hashPOSIX.put("graph", new Character('g'));
    hashPOSIX.put("lower", new Character('l'));
    hashPOSIX.put("print", new Character('p'));
    hashPOSIX.put("punct", new Character('!'));
    hashPOSIX.put("space", new Character('s'));
    hashPOSIX.put("upper", new Character('u'));
    hashPOSIX.put("xdigit", new Character('x'));
    hashPOSIX.put("javastart", new Character('j'));
    hashPOSIX.put("javapart", new Character('k'));
  }
  
  class RERange
  {
    int size = 16;
    int[] minRange = new int[this.size];
    int[] maxRange = new int[this.size];
    int num = 0;
    
    RERange() {}
    
    void delete(int paramInt)
    {
      if ((this.num == 0) || (paramInt >= this.num)) {
        return;
      }
      do
      {
        if (paramInt - 1 >= 0)
        {
          this.minRange[(paramInt - 1)] = this.minRange[paramInt];
          this.maxRange[(paramInt - 1)] = this.maxRange[paramInt];
        }
        paramInt++;
      } while (paramInt < this.num);
      this.num -= 1;
    }
    
    void merge(int paramInt1, int paramInt2)
    {
      for (int i = 0; i < this.num; i++)
      {
        if ((paramInt1 >= this.minRange[i]) && (paramInt2 <= this.maxRange[i])) {
          return;
        }
        if ((paramInt1 <= this.minRange[i]) && (paramInt2 >= this.maxRange[i]))
        {
          delete(i);
          merge(paramInt1, paramInt2);
          return;
        }
        if ((paramInt1 >= this.minRange[i]) && (paramInt1 <= this.maxRange[i]))
        {
          paramInt1 = this.minRange[i];
          delete(i);
          merge(paramInt1, paramInt2);
          return;
        }
        if ((paramInt2 >= this.minRange[i]) && (paramInt2 <= this.maxRange[i]))
        {
          paramInt2 = this.maxRange[i];
          delete(i);
          merge(paramInt1, paramInt2);
          return;
        }
      }
      if (this.num >= this.size)
      {
        this.size *= 2;
        int[] arrayOfInt1 = new int[this.size];
        int[] arrayOfInt2 = new int[this.size];
        System.arraycopy(this.minRange, 0, arrayOfInt1, 0, this.num);
        System.arraycopy(this.maxRange, 0, arrayOfInt2, 0, this.num);
        this.minRange = arrayOfInt1;
        this.maxRange = arrayOfInt2;
      }
      this.minRange[this.num] = paramInt1;
      this.maxRange[this.num] = paramInt2;
      this.num += 1;
    }
    
    void remove(int paramInt1, int paramInt2)
    {
      for (int i = 0; i < this.num; i++)
      {
        if ((this.minRange[i] >= paramInt1) && (this.maxRange[i] <= paramInt2))
        {
          delete(i);
          return;
        }
        if ((paramInt1 >= this.minRange[i]) && (paramInt2 <= this.maxRange[i]))
        {
          int j = this.minRange[i];
          int k = this.maxRange[i];
          delete(i);
          if (j < paramInt1) {
            merge(j, paramInt1 - 1);
          }
          if (paramInt2 < k) {
            merge(paramInt2 + 1, k);
          }
          return;
        }
        if ((this.minRange[i] >= paramInt1) && (this.minRange[i] <= paramInt2))
        {
          this.minRange[i] = (paramInt2 + 1);
          return;
        }
        if ((this.maxRange[i] >= paramInt1) && (this.maxRange[i] <= paramInt2))
        {
          this.maxRange[i] = (paramInt1 - 1);
          return;
        }
      }
    }
    
    void include(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      if (paramBoolean) {
        merge(paramInt1, paramInt2);
      } else {
        remove(paramInt1, paramInt2);
      }
    }
    
    void include(char paramChar, boolean paramBoolean)
    {
      include(paramChar, paramChar, paramBoolean);
    }
  }
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/jakarta-regexp-1.5.jar!/org/apache/regexp/RECompiler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */