/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.text.FieldPosition;
/*    */ import java.text.ParsePosition;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelativeTimeDateFormat
/*    */   extends DateFormat
/*    */ {
/*    */   protected final long startTime;
/*    */   
/*    */   public RelativeTimeDateFormat()
/*    */   {
/* 30 */     this.startTime = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public StringBuffer format(Date date, StringBuffer sbuf, FieldPosition fieldPosition)
/*    */   {
/* 43 */     return sbuf.append(date.getTime() - this.startTime);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Date parse(String s, ParsePosition pos)
/*    */   {
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/helpers/RelativeTimeDateFormat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */