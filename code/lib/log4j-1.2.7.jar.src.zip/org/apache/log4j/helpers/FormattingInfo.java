/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormattingInfo
/*    */ {
/* 22 */   int min = -1;
/* 23 */   int max = Integer.MAX_VALUE;
/* 24 */   boolean leftAlign = false;
/*    */   
/*    */   void reset() {
/* 27 */     this.min = -1;
/* 28 */     this.max = Integer.MAX_VALUE;
/* 29 */     this.leftAlign = false;
/*    */   }
/*    */   
/*    */   void dump() {
/* 33 */     LogLog.debug("min=" + this.min + ", max=" + this.max + ", leftAlign=" + this.leftAlign);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/helpers/FormattingInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */