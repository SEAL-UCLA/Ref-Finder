/*     */ package org.apache.log4j.helpers;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.ParsePosition;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ISO8601DateFormat
/*     */   extends AbsoluteTimeDateFormat
/*     */ {
/*     */   private static long lastTime;
/*     */   
/*     */   public ISO8601DateFormat() {}
/*     */   
/*     */   public ISO8601DateFormat(TimeZone timeZone)
/*     */   {
/*  41 */     super(timeZone);
/*     */   }
/*     */   
/*     */ 
/*  45 */   private static char[] lastTimeString = new char[20];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringBuffer format(Date date, StringBuffer sbuf, FieldPosition fieldPosition)
/*     */   {
/*  57 */     long now = date.getTime();
/*  58 */     int millis = (int)(now % 1000L);
/*     */     
/*  60 */     if (now - millis != lastTime)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  65 */       this.calendar.setTime(date);
/*     */       
/*  67 */       int start = sbuf.length();
/*     */       
/*  69 */       int year = this.calendar.get(1);
/*  70 */       sbuf.append(year);
/*     */       
/*     */       String month;
/*  73 */       switch (this.calendar.get(2)) {
/*  74 */       case 0:  month = "-01-"; break;
/*  75 */       case 1:  month = "-02-"; break;
/*  76 */       case 2:  month = "-03-"; break;
/*  77 */       case 3:  month = "-04-"; break;
/*  78 */       case 4:  month = "-05-"; break;
/*  79 */       case 5:  month = "-06-"; break;
/*  80 */       case 6:  month = "-07-"; break;
/*  81 */       case 7:  month = "-08-"; break;
/*  82 */       case 8:  month = "-09-"; break;
/*  83 */       case 9:  month = "-10-"; break;
/*  84 */       case 10:  month = "-11-"; break;
/*  85 */       case 11:  month = "-12-"; break;
/*  86 */       default:  month = "-NA-";
/*     */       }
/*  88 */       sbuf.append(month);
/*     */       
/*  90 */       int day = this.calendar.get(5);
/*  91 */       if (day < 10)
/*  92 */         sbuf.append('0');
/*  93 */       sbuf.append(day);
/*     */       
/*  95 */       sbuf.append(' ');
/*     */       
/*  97 */       int hour = this.calendar.get(11);
/*  98 */       if (hour < 10) {
/*  99 */         sbuf.append('0');
/*     */       }
/* 101 */       sbuf.append(hour);
/* 102 */       sbuf.append(':');
/*     */       
/* 104 */       int mins = this.calendar.get(12);
/* 105 */       if (mins < 10) {
/* 106 */         sbuf.append('0');
/*     */       }
/* 108 */       sbuf.append(mins);
/* 109 */       sbuf.append(':');
/*     */       
/* 111 */       int secs = this.calendar.get(13);
/* 112 */       if (secs < 10) {
/* 113 */         sbuf.append('0');
/*     */       }
/* 115 */       sbuf.append(secs);
/*     */       
/* 117 */       sbuf.append(',');
/*     */       
/*     */ 
/* 120 */       sbuf.getChars(start, sbuf.length(), lastTimeString, 0);
/* 121 */       lastTime = now - millis;
/*     */     }
/*     */     else {
/* 124 */       sbuf.append(lastTimeString);
/*     */     }
/*     */     
/*     */ 
/* 128 */     if (millis < 100)
/* 129 */       sbuf.append('0');
/* 130 */     if (millis < 10) {
/* 131 */       sbuf.append('0');
/*     */     }
/* 133 */     sbuf.append(millis);
/* 134 */     return sbuf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date parse(String s, ParsePosition pos)
/*     */   {
/* 142 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/helpers/ISO8601DateFormat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */