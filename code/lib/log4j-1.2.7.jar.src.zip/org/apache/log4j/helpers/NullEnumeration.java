/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullEnumeration
/*    */   implements Enumeration
/*    */ {
/* 22 */   private static final NullEnumeration instance = new NullEnumeration();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static NullEnumeration getInstance()
/*    */   {
/* 29 */     return instance;
/*    */   }
/*    */   
/*    */   public boolean hasMoreElements()
/*    */   {
/* 34 */     return false;
/*    */   }
/*    */   
/*    */   public Object nextElement()
/*    */   {
/* 39 */     throw new NoSuchElementException();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/helpers/NullEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */