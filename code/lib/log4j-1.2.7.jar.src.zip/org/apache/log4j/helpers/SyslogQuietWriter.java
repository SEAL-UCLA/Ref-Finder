/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import org.apache.log4j.spi.ErrorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyslogQuietWriter
/*    */   extends QuietWriter
/*    */ {
/*    */   int syslogFacility;
/*    */   int level;
/*    */   
/*    */   public SyslogQuietWriter(Writer writer, int syslogFacility, ErrorHandler eh)
/*    */   {
/* 29 */     super(writer, eh);
/* 30 */     this.syslogFacility = syslogFacility;
/*    */   }
/*    */   
/*    */   public void setLevel(int level)
/*    */   {
/* 35 */     this.level = level;
/*    */   }
/*    */   
/*    */   public void setSyslogFacility(int syslogFacility)
/*    */   {
/* 40 */     this.syslogFacility = syslogFacility;
/*    */   }
/*    */   
/*    */   public void write(String string)
/*    */   {
/* 45 */     super.write("<" + (this.syslogFacility | this.level) + ">" + string);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/helpers/SyslogQuietWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */