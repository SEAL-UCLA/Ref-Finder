/*    */ package org.apache.log4j.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertySetterException
/*    */   extends Exception
/*    */ {
/*    */   protected Throwable rootCause;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PropertySetterException(String msg)
/*    */   {
/* 22 */     super(msg);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PropertySetterException(Throwable rootCause)
/*    */   {
/* 29 */     this.rootCause = rootCause;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 37 */     String msg = super.getMessage();
/* 38 */     if ((msg == null) && (this.rootCause != null)) {
/* 39 */       msg = this.rootCause.getMessage();
/*    */     }
/* 41 */     return msg;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/config/PropertySetterException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */