/*    */ package org.apache.log4j.spi;
/*    */ 
/*    */ import org.apache.log4j.Category;
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.helpers.LogLog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RootCategory
/*    */   extends Logger
/*    */ {
/*    */   public RootCategory(Level level)
/*    */   {
/* 35 */     super("root");
/* 36 */     setLevel(level);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final Level getChainedLevel()
/*    */   {
/* 47 */     return this.level;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void setLevel(Level level)
/*    */   {
/* 58 */     if (level == null) {
/* 59 */       LogLog.error("You have tried to set a null level to root.", new Throwable());
/*    */     }
/*    */     else
/*    */     {
/* 63 */       this.level = level;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public final void setPriority(Level level)
/*    */   {
/* 70 */     setLevel(level);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/spi/RootCategory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */