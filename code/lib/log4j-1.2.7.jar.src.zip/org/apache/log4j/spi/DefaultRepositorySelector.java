/*    */ package org.apache.log4j.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultRepositorySelector
/*    */   implements RepositorySelector
/*    */ {
/*    */   final LoggerRepository repository;
/*    */   
/*    */ 
/*    */   public DefaultRepositorySelector(LoggerRepository repository)
/*    */   {
/* 13 */     this.repository = repository;
/*    */   }
/*    */   
/*    */   public LoggerRepository getLoggerRepository()
/*    */   {
/* 18 */     return this.repository;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/spi/DefaultRepositorySelector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */