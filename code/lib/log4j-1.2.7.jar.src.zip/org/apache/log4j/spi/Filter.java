package org.apache.log4j.spi;

public abstract class Filter
  implements OptionHandler
{
  public Filter next;
  public static final int DENY = -1;
  public static final int NEUTRAL = 0;
  public static final int ACCEPT = 1;
  
  public void activateOptions() {}
  
  public abstract int decide(LoggingEvent paramLoggingEvent);
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/spi/Filter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */