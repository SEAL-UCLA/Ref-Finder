package org.apache.log4j.jmx;

import java.lang.reflect.Method;

class MethodUnion
{
  Method readMethod;
  Method writeMethod;
  
  MethodUnion(Method paramMethod1, Method paramMethod2)
  {
    this.readMethod = paramMethod1;
    this.writeMethod = paramMethod2;
  }
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/jmx/MethodUnion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */