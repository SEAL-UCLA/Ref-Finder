/*    */ package org.apache.log4j;
/*    */ 
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ import org.apache.log4j.spi.OptionHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Layout
/*    */   implements OptionHandler
/*    */ {
/* 24 */   public static final String LINE_SEP = System.getProperty("line.separator");
/* 25 */   public static final int LINE_SEP_LEN = LINE_SEP.length();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract String format(LoggingEvent paramLoggingEvent);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getContentType()
/*    */   {
/* 41 */     return "text/plain";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getHeader()
/*    */   {
/* 49 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFooter()
/*    */   {
/* 57 */     return null;
/*    */   }
/*    */   
/*    */   public abstract boolean ignoresThrowable();
/*    */   
/*    */   public abstract void activateOptions();
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/Layout.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */