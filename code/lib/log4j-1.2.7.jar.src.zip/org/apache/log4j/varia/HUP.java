/*     */ package org.apache.log4j.varia;
/*     */ 
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HUP
/*     */   extends Thread
/*     */ {
/*     */   int port;
/*     */   ExternallyRolledFileAppender er;
/*     */   
/*     */   HUP(ExternallyRolledFileAppender er, int port)
/*     */   {
/* 102 */     this.er = er;
/* 103 */     this.port = port;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/* 108 */     while (!isInterrupted()) {
/*     */       try {
/* 110 */         ServerSocket serverSocket = new ServerSocket(this.port);
/*     */         for (;;) {
/* 112 */           Socket socket = serverSocket.accept();
/* 113 */           LogLog.debug("Connected to client at " + socket.getInetAddress());
/* 114 */           new Thread(new HUPNode(socket, this.er)).start();
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 118 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/varia/HUP.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */