/*    */ package org.apache.log4j;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CategoryKey
/*    */ {
/*    */   String name;
/*    */   
/*    */ 
/*    */ 
/*    */   int hashCache;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   CategoryKey(String name)
/*    */   {
/* 20 */     this.name = name.intern();
/* 21 */     this.hashCache = name.hashCode();
/*    */   }
/*    */   
/*    */ 
/*    */   public final int hashCode()
/*    */   {
/* 27 */     return this.hashCache;
/*    */   }
/*    */   
/*    */ 
/*    */   public final boolean equals(Object rArg)
/*    */   {
/* 33 */     if (this == rArg) {
/* 34 */       return true;
/*    */     }
/* 36 */     if ((rArg != null) && (CategoryKey.class == rArg.getClass())) {
/* 37 */       return this.name == ((CategoryKey)rArg).name;
/*    */     }
/* 39 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/CategoryKey.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */