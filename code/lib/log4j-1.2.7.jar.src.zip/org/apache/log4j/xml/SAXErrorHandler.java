/*    */ package org.apache.log4j.xml;
/*    */ 
/*    */ import org.apache.log4j.helpers.LogLog;
/*    */ import org.xml.sax.ErrorHandler;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SAXErrorHandler
/*    */   implements ErrorHandler
/*    */ {
/*    */   public void error(SAXParseException ex)
/*    */   {
/* 18 */     LogLog.error("Parsing error on line " + ex.getLineNumber() + " and column " + ex.getColumnNumber());
/*    */     
/* 20 */     LogLog.error(ex.getMessage(), ex.getException());
/*    */   }
/*    */   
/*    */ 
/*    */   public void fatalError(SAXParseException ex)
/*    */   {
/* 26 */     error(ex);
/*    */   }
/*    */   
/*    */   public void warning(SAXParseException ex)
/*    */   {
/* 31 */     LogLog.warn("Parsing error on line " + ex.getLineNumber() + " and column " + ex.getColumnNumber());
/*    */     
/* 33 */     LogLog.warn(ex.getMessage(), ex.getException());
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/xml/SAXErrorHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */