/*    */ package org.apache.log4j.or.sax;
/*    */ 
/*    */ import org.apache.log4j.or.ObjectRenderer;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributesRenderer
/*    */   implements ObjectRenderer
/*    */ {
/*    */   public String doRender(Object o)
/*    */   {
/* 31 */     if ((o instanceof Attributes)) {
/* 32 */       StringBuffer sbuf = new StringBuffer();
/* 33 */       Attributes a = (Attributes)o;
/* 34 */       int len = a.getLength();
/* 35 */       boolean first = true;
/* 36 */       for (int i = 0; i < len; i++) {
/* 37 */         if (first) {
/* 38 */           first = false;
/*    */         } else {
/* 40 */           sbuf.append(", ");
/*    */         }
/* 42 */         sbuf.append(a.getQName(i));
/* 43 */         sbuf.append('=');
/* 44 */         sbuf.append(a.getValue(i));
/*    */       }
/* 46 */       return sbuf.toString();
/*    */     }
/* 48 */     return o.toString();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/or/sax/AttributesRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */