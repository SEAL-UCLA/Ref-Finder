package org.apache.log4j.or;

public abstract interface ObjectRenderer
{
  public abstract String doRender(Object paramObject);
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/or/ObjectRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */