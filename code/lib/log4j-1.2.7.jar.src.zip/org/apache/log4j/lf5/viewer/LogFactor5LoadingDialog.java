/*    */ package org.apache.log4j.lf5.viewer;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.FlowLayout;
/*    */ import java.awt.GridBagLayout;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogFactor5LoadingDialog
/*    */   extends LogFactor5Dialog
/*    */ {
/*    */   public LogFactor5LoadingDialog(JFrame jframe, String message)
/*    */   {
/* 40 */     super(jframe, "LogFactor5", false);
/*    */     
/* 42 */     JPanel bottom = new JPanel();
/* 43 */     bottom.setLayout(new FlowLayout());
/*    */     
/* 45 */     JPanel main = new JPanel();
/* 46 */     main.setLayout(new GridBagLayout());
/* 47 */     wrapStringOnPanel(message, main);
/*    */     
/* 49 */     getContentPane().add(main, "Center");
/* 50 */     getContentPane().add(bottom, "South");
/* 51 */     show();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/lf5/viewer/LogFactor5LoadingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */