/*     */ package org.apache.log4j.lf5.util;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceUtils
/*     */ {
/*     */   public static InputStream getResourceAsStream(Object object, Resource resource)
/*     */   {
/*  64 */     ClassLoader loader = object.getClass().getClassLoader();
/*     */     
/*  66 */     InputStream in = null;
/*     */     
/*  68 */     if (loader != null) {
/*  69 */       in = loader.getResourceAsStream(resource.getName());
/*     */     } else {
/*  71 */       in = ClassLoader.getSystemResourceAsStream(resource.getName());
/*     */     }
/*     */     
/*  74 */     return in;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static URL getResourceAsURL(Object object, Resource resource)
/*     */   {
/*  93 */     ClassLoader loader = object.getClass().getClassLoader();
/*     */     
/*  95 */     URL url = null;
/*     */     
/*  97 */     if (loader != null) {
/*  98 */       url = loader.getResource(resource.getName());
/*     */     } else {
/* 100 */       url = ClassLoader.getSystemResource(resource.getName());
/*     */     }
/*     */     
/* 103 */     return url;
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/log4j-1.2.7.jar!/org/apache/log4j/lf5/util/ResourceUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */