/*    */ package junit.runner;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static String id()
/*    */   {
/* 12 */     return "4.7";
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 16 */     System.out.println(id());
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/junit/runner/Version.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */