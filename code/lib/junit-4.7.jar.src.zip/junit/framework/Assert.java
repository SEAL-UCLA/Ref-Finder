/*     */ package junit.framework;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assert
/*     */ {
/*     */   public static void assertTrue(String message, boolean condition)
/*     */   {
/*  19 */     if (!condition) {
/*  20 */       fail(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertTrue(boolean condition)
/*     */   {
/*  27 */     assertTrue(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertFalse(String message, boolean condition)
/*     */   {
/*  34 */     assertTrue(message, !condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertFalse(boolean condition)
/*     */   {
/*  41 */     assertFalse(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void fail(String message)
/*     */   {
/*  47 */     throw new AssertionFailedError(message);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void fail()
/*     */   {
/*  53 */     fail(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, Object expected, Object actual)
/*     */   {
/*  60 */     if ((expected == null) && (actual == null))
/*  61 */       return;
/*  62 */     if ((expected != null) && (expected.equals(actual)))
/*  63 */       return;
/*  64 */     failNotEquals(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(Object expected, Object actual)
/*     */   {
/*  71 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(String message, String expected, String actual)
/*     */   {
/*  77 */     if ((expected == null) && (actual == null))
/*  78 */       return;
/*  79 */     if ((expected != null) && (expected.equals(actual)))
/*  80 */       return;
/*  81 */     throw new ComparisonFailure(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(String expected, String actual)
/*     */   {
/*  87 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, double expected, double actual, double delta)
/*     */   {
/*  95 */     if (Double.compare(expected, actual) == 0)
/*  96 */       return;
/*  97 */     if (Math.abs(expected - actual) > delta) {
/*  98 */       failNotEquals(message, new Double(expected), new Double(actual));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(double expected, double actual, double delta)
/*     */   {
/* 105 */     assertEquals(null, expected, actual, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, float expected, float actual, float delta)
/*     */   {
/* 113 */     if (Float.compare(expected, actual) == 0)
/* 114 */       return;
/* 115 */     if (Math.abs(expected - actual) > delta) {
/* 116 */       failNotEquals(message, new Float(expected), new Float(actual));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(float expected, float actual, float delta)
/*     */   {
/* 123 */     assertEquals(null, expected, actual, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, long expected, long actual)
/*     */   {
/* 130 */     assertEquals(message, new Long(expected), new Long(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(long expected, long actual)
/*     */   {
/* 136 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, boolean expected, boolean actual)
/*     */   {
/* 143 */     assertEquals(message, Boolean.valueOf(expected), Boolean.valueOf(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(boolean expected, boolean actual)
/*     */   {
/* 149 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, byte expected, byte actual)
/*     */   {
/* 156 */     assertEquals(message, new Byte(expected), new Byte(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(byte expected, byte actual)
/*     */   {
/* 162 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, char expected, char actual)
/*     */   {
/* 169 */     assertEquals(message, new Character(expected), new Character(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(char expected, char actual)
/*     */   {
/* 175 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, short expected, short actual)
/*     */   {
/* 182 */     assertEquals(message, new Short(expected), new Short(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(short expected, short actual)
/*     */   {
/* 188 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, int expected, int actual)
/*     */   {
/* 195 */     assertEquals(message, new Integer(expected), new Integer(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(int expected, int actual)
/*     */   {
/* 201 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertNotNull(Object object)
/*     */   {
/* 207 */     assertNotNull(null, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(String message, Object object)
/*     */   {
/* 214 */     assertTrue(message, object != null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertNull(Object object)
/*     */   {
/* 220 */     assertNull(null, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertNull(String message, Object object)
/*     */   {
/* 227 */     assertTrue(message, object == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertSame(String message, Object expected, Object actual)
/*     */   {
/* 234 */     if (expected == actual)
/* 235 */       return;
/* 236 */     failNotSame(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertSame(Object expected, Object actual)
/*     */   {
/* 243 */     assertSame(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotSame(String message, Object expected, Object actual)
/*     */   {
/* 251 */     if (expected == actual) {
/* 252 */       failSame(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertNotSame(Object expected, Object actual)
/*     */   {
/* 259 */     assertNotSame(null, expected, actual);
/*     */   }
/*     */   
/*     */   public static void failSame(String message) {
/* 263 */     String formatted = "";
/* 264 */     if (message != null)
/* 265 */       formatted = message + " ";
/* 266 */     fail(formatted + "expected not same");
/*     */   }
/*     */   
/*     */   public static void failNotSame(String message, Object expected, Object actual) {
/* 270 */     String formatted = "";
/* 271 */     if (message != null)
/* 272 */       formatted = message + " ";
/* 273 */     fail(formatted + "expected same:<" + expected + "> was not:<" + actual + ">");
/*     */   }
/*     */   
/*     */   public static void failNotEquals(String message, Object expected, Object actual) {
/* 277 */     fail(format(message, expected, actual));
/*     */   }
/*     */   
/*     */   public static String format(String message, Object expected, Object actual) {
/* 281 */     String formatted = "";
/* 282 */     if (message != null)
/* 283 */       formatted = message + " ";
/* 284 */     return formatted + "expected:<" + expected + "> but was:<" + actual + ">";
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/junit/framework/Assert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */