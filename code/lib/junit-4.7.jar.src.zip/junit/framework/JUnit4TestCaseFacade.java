/*    */ package junit.framework;
/*    */ 
/*    */ import org.junit.runner.Describable;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ public class JUnit4TestCaseFacade
/*    */   implements Test, Describable
/*    */ {
/*    */   private final Description fDescription;
/*    */   
/*    */   JUnit4TestCaseFacade(Description description)
/*    */   {
/* 13 */     this.fDescription = description;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 18 */     return getDescription().toString();
/*    */   }
/*    */   
/*    */   public int countTestCases() {
/* 22 */     return 1;
/*    */   }
/*    */   
/*    */   public void run(TestResult result) {
/* 26 */     throw new RuntimeException("This test stub created only for informational purposes.");
/*    */   }
/*    */   
/*    */   public Description getDescription()
/*    */   {
/* 31 */     return this.fDescription;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/junit/framework/JUnit4TestCaseFacade.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */