/*     */ package junit.framework;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestSuite
/*     */   implements Test
/*     */ {
/*     */   private String fName;
/*     */   
/*     */   public static Test createTest(Class<? extends TestCase> theClass, String name)
/*     */   {
/*     */     Constructor<? extends TestCase> constructor;
/*     */     try
/*     */     {
/*  54 */       constructor = getTestConstructor(theClass);
/*     */     } catch (NoSuchMethodException e) {
/*  56 */       return warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()");
/*     */     }
/*     */     Object test;
/*     */     try {
/*  60 */       if (constructor.getParameterTypes().length == 0) {
/*  61 */         Object test = constructor.newInstance(new Object[0]);
/*  62 */         if ((test instanceof TestCase))
/*  63 */           ((TestCase)test).setName(name);
/*     */       } else {
/*  65 */         test = constructor.newInstance(new Object[] { name });
/*     */       }
/*     */     } catch (InstantiationException e) {
/*  68 */       return warning("Cannot instantiate test case: " + name + " (" + exceptionToString(e) + ")");
/*     */     } catch (InvocationTargetException e) {
/*  70 */       return warning("Exception in constructor: " + name + " (" + exceptionToString(e.getTargetException()) + ")");
/*     */     } catch (IllegalAccessException e) {
/*  72 */       return warning("Cannot access test case: " + name + " (" + exceptionToString(e) + ")");
/*     */     }
/*  74 */     return (Test)test;
/*     */   }
/*     */   
/*     */ 
/*     */   public static Constructor<? extends TestCase> getTestConstructor(Class<? extends TestCase> theClass)
/*     */     throws NoSuchMethodException
/*     */   {
/*     */     try
/*     */     {
/*  83 */       return theClass.getConstructor(new Class[] { String.class });
/*     */     }
/*     */     catch (NoSuchMethodException e) {}
/*     */     
/*  87 */     return theClass.getConstructor(new Class[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Test warning(final String message)
/*     */   {
/*  94 */     new TestCase("warning")
/*     */     {
/*     */       protected void runTest() {
/*  97 */         fail(message);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String exceptionToString(Throwable t)
/*     */   {
/* 106 */     StringWriter stringWriter = new StringWriter();
/* 107 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 108 */     t.printStackTrace(writer);
/* 109 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 114 */   private Vector<Test> fTests = new Vector(10);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<? extends TestCase> theClass)
/*     */   {
/* 129 */     this.fName = theClass.getName();
/*     */     try {
/* 131 */       getTestConstructor(theClass);
/*     */     } catch (NoSuchMethodException e) {
/* 133 */       addTest(warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()"));
/* 134 */       return;
/*     */     }
/*     */     
/* 137 */     if (!Modifier.isPublic(theClass.getModifiers())) {
/* 138 */       addTest(warning("Class " + theClass.getName() + " is not public"));
/* 139 */       return;
/*     */     }
/*     */     
/* 142 */     Class<?> superClass = theClass;
/* 143 */     List<String> names = new ArrayList();
/* 144 */     while (Test.class.isAssignableFrom(superClass)) {
/* 145 */       for (Method each : superClass.getDeclaredMethods())
/* 146 */         addTestMethod(each, names, theClass);
/* 147 */       superClass = superClass.getSuperclass();
/*     */     }
/* 149 */     if (this.fTests.size() == 0) {
/* 150 */       addTest(warning("No tests found in " + theClass.getName()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<? extends TestCase> theClass, String name)
/*     */   {
/* 158 */     this(theClass);
/* 159 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TestSuite(String name)
/*     */   {
/* 166 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<?>... classes)
/*     */   {
/* 174 */     for (Class<?> each : classes) {
/* 175 */       addTest(new TestSuite(each.asSubclass(TestCase.class)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<? extends TestCase>[] classes, String name)
/*     */   {
/* 183 */     this(classes);
/* 184 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTest(Test test)
/*     */   {
/* 191 */     this.fTests.add(test);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTestSuite(Class<? extends TestCase> testClass)
/*     */   {
/* 198 */     addTest(new TestSuite(testClass));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int countTestCases()
/*     */   {
/* 205 */     int count = 0;
/* 206 */     for (Test each : this.fTests)
/* 207 */       count += each.countTestCases();
/* 208 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 217 */     return this.fName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void run(TestResult result)
/*     */   {
/* 224 */     for (Test each : this.fTests) {
/* 225 */       if (result.shouldStop())
/*     */         break;
/* 227 */       runTest(each, result);
/*     */     }
/*     */   }
/*     */   
/*     */   public void runTest(Test test, TestResult result) {
/* 232 */     test.run(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 240 */     this.fName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Test testAt(int index)
/*     */   {
/* 247 */     return (Test)this.fTests.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int testCount()
/*     */   {
/* 254 */     return this.fTests.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Enumeration<Test> tests()
/*     */   {
/* 261 */     return this.fTests.elements();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 268 */     if (getName() != null)
/* 269 */       return getName();
/* 270 */     return super.toString();
/*     */   }
/*     */   
/*     */   private void addTestMethod(Method m, List<String> names, Class<? extends TestCase> theClass) {
/* 274 */     String name = m.getName();
/* 275 */     if (names.contains(name))
/* 276 */       return;
/* 277 */     if (!isPublicTestMethod(m)) {
/* 278 */       if (isTestMethod(m))
/* 279 */         addTest(warning("Test method isn't public: " + m.getName() + "(" + theClass.getCanonicalName() + ")"));
/* 280 */       return;
/*     */     }
/* 282 */     names.add(name);
/* 283 */     addTest(createTest(theClass, name));
/*     */   }
/*     */   
/*     */   private boolean isPublicTestMethod(Method m) {
/* 287 */     return (isTestMethod(m)) && (Modifier.isPublic(m.getModifiers()));
/*     */   }
/*     */   
/*     */   private boolean isTestMethod(Method m) {
/* 291 */     return (m.getParameterTypes().length == 0) && (m.getName().startsWith("test")) && (m.getReturnType().equals(Void.TYPE));
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/junit/framework/TestSuite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */