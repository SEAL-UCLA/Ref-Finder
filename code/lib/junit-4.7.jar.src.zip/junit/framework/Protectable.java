package junit.framework;

public abstract interface Protectable
{
  public abstract void protect()
    throws Throwable;
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/junit/framework/Protectable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */