/*     */ package junit.framework;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestResult
/*     */ {
/*     */   protected List<TestFailure> fFailures;
/*     */   protected List<TestFailure> fErrors;
/*     */   protected List<TestListener> fListeners;
/*     */   protected int fRunTests;
/*     */   private boolean fStop;
/*     */   
/*     */   public TestResult()
/*     */   {
/*  25 */     this.fFailures = new ArrayList();
/*  26 */     this.fErrors = new ArrayList();
/*  27 */     this.fListeners = new ArrayList();
/*  28 */     this.fRunTests = 0;
/*  29 */     this.fStop = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void addError(Test test, Throwable t)
/*     */   {
/*  36 */     this.fErrors.add(new TestFailure(test, t));
/*  37 */     for (TestListener each : cloneListeners()) {
/*  38 */       each.addError(test, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void addFailure(Test test, AssertionFailedError t)
/*     */   {
/*  45 */     this.fFailures.add(new TestFailure(test, t));
/*  46 */     for (TestListener each : cloneListeners()) {
/*  47 */       each.addFailure(test, t);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void addListener(TestListener listener)
/*     */   {
/*  53 */     this.fListeners.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void removeListener(TestListener listener)
/*     */   {
/*  59 */     this.fListeners.remove(listener);
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized List<TestListener> cloneListeners()
/*     */   {
/*  65 */     List<TestListener> result = new ArrayList();
/*  66 */     result.addAll(this.fListeners);
/*  67 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public void endTest(Test test)
/*     */   {
/*  73 */     for (TestListener each : cloneListeners()) {
/*  74 */       each.endTest(test);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized int errorCount()
/*     */   {
/*  80 */     return this.fErrors.size();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized Enumeration<TestFailure> errors()
/*     */   {
/*  86 */     return Collections.enumeration(this.fErrors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int failureCount()
/*     */   {
/*  94 */     return this.fFailures.size();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized Enumeration<TestFailure> failures()
/*     */   {
/* 100 */     return Collections.enumeration(this.fFailures);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void run(final TestCase test)
/*     */   {
/* 107 */     startTest(test);
/* 108 */     Protectable p = new Protectable() {
/*     */       public void protect() throws Throwable {
/* 110 */         test.runBare();
/*     */       }
/* 112 */     };
/* 113 */     runProtected(test, p);
/*     */     
/* 115 */     endTest(test);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized int runCount()
/*     */   {
/* 121 */     return this.fRunTests;
/*     */   }
/*     */   
/*     */   public void runProtected(Test test, Protectable p)
/*     */   {
/*     */     try
/*     */     {
/* 128 */       p.protect();
/*     */     }
/*     */     catch (AssertionFailedError e) {
/* 131 */       addFailure(test, e);
/*     */     }
/*     */     catch (ThreadDeath e) {
/* 134 */       throw e;
/*     */     }
/*     */     catch (Throwable e) {
/* 137 */       addError(test, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean shouldStop()
/*     */   {
/* 144 */     return this.fStop;
/*     */   }
/*     */   
/*     */ 
/*     */   public void startTest(Test test)
/*     */   {
/* 150 */     int count = test.countTestCases();
/* 151 */     synchronized (this) {
/* 152 */       this.fRunTests += count;
/*     */     }
/* 154 */     for (TestListener each : cloneListeners()) {
/* 155 */       each.startTest(test);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void stop()
/*     */   {
/* 161 */     this.fStop = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean wasSuccessful()
/*     */   {
/* 167 */     return (failureCount() == 0) && (errorCount() == 0);
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/junit/framework/TestResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */