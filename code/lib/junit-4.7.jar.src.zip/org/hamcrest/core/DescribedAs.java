/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DescribedAs<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final String descriptionTemplate;
/*    */   private final org.hamcrest.Matcher<T> matcher;
/*    */   private final Object[] values;
/* 20 */   private static final Pattern ARG_PATTERN = Pattern.compile("%([0-9]+)");
/*    */   
/*    */   public DescribedAs(String descriptionTemplate, org.hamcrest.Matcher<T> matcher, Object[] values) {
/* 23 */     this.descriptionTemplate = descriptionTemplate;
/* 24 */     this.matcher = matcher;
/* 25 */     this.values = ((Object[])values.clone());
/*    */   }
/*    */   
/*    */   public boolean matches(Object o) {
/* 29 */     return this.matcher.matches(o);
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 33 */     java.util.regex.Matcher arg = ARG_PATTERN.matcher(this.descriptionTemplate);
/*    */     
/* 35 */     int textStart = 0;
/* 36 */     while (arg.find()) {
/* 37 */       description.appendText(this.descriptionTemplate.substring(textStart, arg.start()));
/* 38 */       int argIndex = Integer.parseInt(arg.group(1));
/* 39 */       description.appendValue(this.values[argIndex]);
/* 40 */       textStart = arg.end();
/*    */     }
/*    */     
/* 43 */     if (textStart < this.descriptionTemplate.length()) {
/* 44 */       description.appendText(this.descriptionTemplate.substring(textStart));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> org.hamcrest.Matcher<T> describedAs(String description, org.hamcrest.Matcher<T> matcher, Object... values)
/*    */   {
/* 53 */     return new DescribedAs(description, matcher, values);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/DescribedAs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */