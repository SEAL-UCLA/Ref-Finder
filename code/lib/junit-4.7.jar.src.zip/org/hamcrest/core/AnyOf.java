/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnyOf<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final Iterable<Matcher<? extends T>> matchers;
/*    */   
/*    */   public AnyOf(Iterable<Matcher<? extends T>> matchers)
/*    */   {
/* 20 */     this.matchers = matchers;
/*    */   }
/*    */   
/*    */   public boolean matches(Object o) {
/* 24 */     for (Matcher<? extends T> matcher : this.matchers) {
/* 25 */       if (matcher.matches(o)) {
/* 26 */         return true;
/*    */       }
/*    */     }
/* 29 */     return false;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 33 */     description.appendList("(", " or ", ")", this.matchers);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> anyOf(Matcher<? extends T>... matchers)
/*    */   {
/* 41 */     return anyOf(Arrays.asList(matchers));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> anyOf(Iterable<Matcher<? extends T>> matchers)
/*    */   {
/* 49 */     return new AnyOf(matchers);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/AnyOf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */