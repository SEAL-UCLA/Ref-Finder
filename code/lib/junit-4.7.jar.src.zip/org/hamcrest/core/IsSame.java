/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsSame<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final T object;
/*    */   
/*    */   public IsSame(T object)
/*    */   {
/* 18 */     this.object = object;
/*    */   }
/*    */   
/*    */   public boolean matches(Object arg) {
/* 22 */     return arg == this.object;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 26 */     description.appendText("same(").appendValue(this.object).appendText(")");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> sameInstance(T object)
/*    */   {
/* 37 */     return new IsSame(object);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/IsSame.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */