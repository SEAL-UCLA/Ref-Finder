/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsEqual<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final Object object;
/*    */   
/*    */   public IsEqual(T equalArg)
/*    */   {
/* 21 */     this.object = equalArg;
/*    */   }
/*    */   
/*    */   public boolean matches(Object arg) {
/* 25 */     return areEqual(this.object, arg);
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 29 */     description.appendValue(this.object);
/*    */   }
/*    */   
/*    */   private static boolean areEqual(Object o1, Object o2) {
/* 33 */     if ((o1 == null) || (o2 == null))
/* 34 */       return (o1 == null) && (o2 == null);
/* 35 */     if (isArray(o1)) {
/* 36 */       return (isArray(o2)) && (areArraysEqual(o1, o2));
/*    */     }
/* 38 */     return o1.equals(o2);
/*    */   }
/*    */   
/*    */   private static boolean areArraysEqual(Object o1, Object o2)
/*    */   {
/* 43 */     return (areArrayLengthsEqual(o1, o2)) && (areArrayElementsEqual(o1, o2));
/*    */   }
/*    */   
/*    */   private static boolean areArrayLengthsEqual(Object o1, Object o2)
/*    */   {
/* 48 */     return Array.getLength(o1) == Array.getLength(o2);
/*    */   }
/*    */   
/*    */   private static boolean areArrayElementsEqual(Object o1, Object o2) {
/* 52 */     for (int i = 0; i < Array.getLength(o1); i++) {
/* 53 */       if (!areEqual(Array.get(o1, i), Array.get(o2, i))) return false;
/*    */     }
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   private static boolean isArray(Object o) {
/* 59 */     return o.getClass().isArray();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> equalTo(T operand)
/*    */   {
/* 68 */     return new IsEqual(operand);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/IsEqual.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */