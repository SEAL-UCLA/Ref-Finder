/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsNull<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   public boolean matches(Object o)
/*    */   {
/* 16 */     return o == null;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 20 */     description.appendText("null");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> nullValue()
/*    */   {
/* 28 */     return new IsNull();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> notNullValue()
/*    */   {
/* 36 */     return IsNot.not(nullValue());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> nullValue(Class<T> type)
/*    */   {
/* 44 */     return nullValue();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> notNullValue(Class<T> type)
/*    */   {
/* 52 */     return notNullValue();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/IsNull.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */