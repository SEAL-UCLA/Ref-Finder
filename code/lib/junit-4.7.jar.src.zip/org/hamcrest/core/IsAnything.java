/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsAnything<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final String description;
/*    */   
/*    */   public IsAnything()
/*    */   {
/* 19 */     this("ANYTHING");
/*    */   }
/*    */   
/*    */   public IsAnything(String description) {
/* 23 */     this.description = description;
/*    */   }
/*    */   
/*    */   public boolean matches(Object o) {
/* 27 */     return true;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 31 */     description.appendText(this.description);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> anything()
/*    */   {
/* 39 */     return new IsAnything();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> anything(String description)
/*    */   {
/* 49 */     return new IsAnything(description);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> any(Class<T> type)
/*    */   {
/* 57 */     return new IsAnything();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/IsAnything.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */