/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllOf<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final Iterable<Matcher<? extends T>> matchers;
/*    */   
/*    */   public AllOf(Iterable<Matcher<? extends T>> matchers)
/*    */   {
/* 19 */     this.matchers = matchers;
/*    */   }
/*    */   
/*    */   public boolean matches(Object o) {
/* 23 */     for (Matcher<? extends T> matcher : this.matchers) {
/* 24 */       if (!matcher.matches(o)) {
/* 25 */         return false;
/*    */       }
/*    */     }
/* 28 */     return true;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 32 */     description.appendList("(", " and ", ")", this.matchers);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> allOf(Matcher<? extends T>... matchers)
/*    */   {
/* 40 */     return allOf(Arrays.asList(matchers));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> allOf(Iterable<Matcher<? extends T>> matchers)
/*    */   {
/* 48 */     return new AllOf(matchers);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/AllOf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */