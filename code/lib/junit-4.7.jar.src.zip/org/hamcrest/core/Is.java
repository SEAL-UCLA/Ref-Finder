/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Is<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final Matcher<T> matcher;
/*    */   
/*    */   public Is(Matcher<T> matcher)
/*    */   {
/* 22 */     this.matcher = matcher;
/*    */   }
/*    */   
/*    */   public boolean matches(Object arg) {
/* 26 */     return this.matcher.matches(arg);
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 30 */     description.appendText("is ").appendDescriptionOf(this.matcher);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> is(Matcher<T> matcher)
/*    */   {
/* 42 */     return new Is(matcher);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> is(T value)
/*    */   {
/* 53 */     return is(IsEqual.equalTo(value));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static Matcher<Object> is(Class<?> type)
/*    */   {
/* 64 */     return is(IsInstanceOf.instanceOf(type));
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/Is.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */