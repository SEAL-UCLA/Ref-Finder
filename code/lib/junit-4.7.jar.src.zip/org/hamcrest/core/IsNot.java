/*    */ package org.hamcrest.core;
/*    */ 
/*    */ import org.hamcrest.BaseMatcher;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsNot<T>
/*    */   extends BaseMatcher<T>
/*    */ {
/*    */   private final Matcher<T> matcher;
/*    */   
/*    */   public IsNot(Matcher<T> matcher)
/*    */   {
/* 19 */     this.matcher = matcher;
/*    */   }
/*    */   
/*    */   public boolean matches(Object arg) {
/* 23 */     return !this.matcher.matches(arg);
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 27 */     description.appendText("not ").appendDescriptionOf(this.matcher);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> not(Matcher<T> matcher)
/*    */   {
/* 35 */     return new IsNot(matcher);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Factory
/*    */   public static <T> Matcher<T> not(T value)
/*    */   {
/* 46 */     return not(IsEqual.equalTo(value));
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/core/IsNot.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */