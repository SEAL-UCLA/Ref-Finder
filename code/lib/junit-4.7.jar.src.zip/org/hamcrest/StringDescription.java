/*    */ package org.hamcrest;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class StringDescription
/*    */   extends BaseDescription
/*    */ {
/*    */   private final Appendable out;
/*    */   
/*    */   public StringDescription()
/*    */   {
/* 12 */     this(new StringBuilder());
/*    */   }
/*    */   
/*    */   public StringDescription(Appendable out) {
/* 16 */     this.out = out;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String toString(SelfDescribing value)
/*    */   {
/* 28 */     return new StringDescription().appendDescriptionOf(value).toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static String asString(SelfDescribing selfDescribing)
/*    */   {
/* 35 */     return toString(selfDescribing);
/*    */   }
/*    */   
/*    */   protected void append(String str) {
/*    */     try {
/* 40 */       this.out.append(str);
/*    */     } catch (IOException e) {
/* 42 */       throw new RuntimeException("Could not write description", e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void append(char c) {
/*    */     try {
/* 48 */       this.out.append(c);
/*    */     } catch (IOException e) {
/* 50 */       throw new RuntimeException("Could not write description", e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 58 */     return this.out.toString();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/StringDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */