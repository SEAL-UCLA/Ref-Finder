/*     */ package org.hamcrest;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import org.hamcrest.internal.ArrayIterator;
/*     */ import org.hamcrest.internal.SelfDescribingValueIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseDescription
/*     */   implements Description
/*     */ {
/*     */   public Description appendText(String text)
/*     */   {
/*  16 */     append(text);
/*  17 */     return this;
/*     */   }
/*     */   
/*     */   public Description appendDescriptionOf(SelfDescribing value) {
/*  21 */     value.describeTo(this);
/*  22 */     return this;
/*     */   }
/*     */   
/*     */   public Description appendValue(Object value) {
/*  26 */     if (value == null) {
/*  27 */       append("null");
/*  28 */     } else if ((value instanceof String)) {
/*  29 */       toJavaSyntax((String)value);
/*  30 */     } else if ((value instanceof Character)) {
/*  31 */       append('"');
/*  32 */       toJavaSyntax(((Character)value).charValue());
/*  33 */       append('"');
/*  34 */     } else if ((value instanceof Short)) {
/*  35 */       append('<');
/*  36 */       append(String.valueOf(value));
/*  37 */       append("s>");
/*  38 */     } else if ((value instanceof Long)) {
/*  39 */       append('<');
/*  40 */       append(String.valueOf(value));
/*  41 */       append("L>");
/*  42 */     } else if ((value instanceof Float)) {
/*  43 */       append('<');
/*  44 */       append(String.valueOf(value));
/*  45 */       append("F>");
/*  46 */     } else if (value.getClass().isArray()) {
/*  47 */       appendValueList("[", ", ", "]", new ArrayIterator(value));
/*     */     } else {
/*  49 */       append('<');
/*  50 */       append(String.valueOf(value));
/*  51 */       append('>');
/*     */     }
/*  53 */     return this;
/*     */   }
/*     */   
/*     */   public <T> Description appendValueList(String start, String separator, String end, T... values) {
/*  57 */     return appendValueList(start, separator, end, Arrays.asList(values));
/*     */   }
/*     */   
/*     */   public <T> Description appendValueList(String start, String separator, String end, Iterable<T> values) {
/*  61 */     return appendValueList(start, separator, end, values.iterator());
/*     */   }
/*     */   
/*     */   private <T> Description appendValueList(String start, String separator, String end, Iterator<T> values) {
/*  65 */     return appendList(start, separator, end, new SelfDescribingValueIterator(values));
/*     */   }
/*     */   
/*     */   public Description appendList(String start, String separator, String end, Iterable<? extends SelfDescribing> values) {
/*  69 */     return appendList(start, separator, end, values.iterator());
/*     */   }
/*     */   
/*     */   private Description appendList(String start, String separator, String end, Iterator<? extends SelfDescribing> i) {
/*  73 */     boolean separate = false;
/*     */     
/*  75 */     append(start);
/*  76 */     while (i.hasNext()) {
/*  77 */       if (separate) append(separator);
/*  78 */       appendDescriptionOf((SelfDescribing)i.next());
/*  79 */       separate = true;
/*     */     }
/*  81 */     append(end);
/*     */     
/*  83 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void append(String str)
/*     */   {
/*  92 */     for (int i = 0; i < str.length(); i++) {
/*  93 */       append(str.charAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract void append(char paramChar);
/*     */   
/*     */   private void toJavaSyntax(String unformatted)
/*     */   {
/* 102 */     append('"');
/* 103 */     for (int i = 0; i < unformatted.length(); i++) {
/* 104 */       toJavaSyntax(unformatted.charAt(i));
/*     */     }
/* 106 */     append('"');
/*     */   }
/*     */   
/*     */   private void toJavaSyntax(char ch) {
/* 110 */     switch (ch) {
/*     */     case '"': 
/* 112 */       append("\\\"");
/* 113 */       break;
/*     */     case '\n': 
/* 115 */       append("\\n");
/* 116 */       break;
/*     */     case '\r': 
/* 118 */       append("\\r");
/* 119 */       break;
/*     */     case '\t': 
/* 121 */       append("\\t");
/* 122 */       break;
/*     */     default: 
/* 124 */       append(ch);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/BaseDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */