/*    */ package org.hamcrest.internal;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class SelfDescribingValueIterator<T> implements Iterator<org.hamcrest.SelfDescribing>
/*    */ {
/*    */   private Iterator<T> values;
/*    */   
/*    */   public SelfDescribingValueIterator(Iterator<T> values)
/*    */   {
/* 11 */     this.values = values;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 15 */     return this.values.hasNext();
/*    */   }
/*    */   
/*    */   public org.hamcrest.SelfDescribing next() {
/* 19 */     return new SelfDescribingValue(this.values.next());
/*    */   }
/*    */   
/*    */   public void remove() {
/* 23 */     this.values.remove();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/hamcrest/internal/SelfDescribingValueIterator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */