/*    */ package org.junit.runner.manipulation;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sorter
/*    */   implements Comparator<Description>
/*    */ {
/* 17 */   public static Sorter NULL = new Sorter(new Comparator() {
/*    */     public int compare(Description o1, Description o2) {
/* 19 */       return 0;
/*    */     }
/* 17 */   });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Comparator<Description> fComparator;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Sorter(Comparator<Description> comparator)
/*    */   {
/* 29 */     this.fComparator = comparator;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void apply(Object object)
/*    */   {
/* 37 */     if ((object instanceof Sortable)) {
/* 38 */       Sortable sortable = (Sortable)object;
/* 39 */       sortable.sort(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public int compare(Description o1, Description o2) {
/* 44 */     return this.fComparator.compare(o1, o2);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runner/manipulation/Sorter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */