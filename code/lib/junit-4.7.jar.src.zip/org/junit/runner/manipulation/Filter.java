/*    */ package org.junit.runner.manipulation;
/*    */ 
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Filter
/*    */ {
/* 19 */   public static Filter ALL = new Filter()
/*    */   {
/*    */     public boolean shouldRun(Description description) {
/* 22 */       return true;
/*    */     }
/*    */     
/*    */     public String describe()
/*    */     {
/* 27 */       return "all tests";
/*    */     }
/*    */   };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Filter matchMethodDescription(Description desiredDescription)
/*    */   {
/* 36 */     new Filter()
/*    */     {
/*    */       public boolean shouldRun(Description description) {
/* 39 */         if (description.isTest()) {
/* 40 */           return this.val$desiredDescription.equals(description);
/*    */         }
/*    */         
/* 43 */         for (Description each : description.getChildren())
/* 44 */           if (shouldRun(each))
/* 45 */             return true;
/* 46 */         return false;
/*    */       }
/*    */       
/*    */       public String describe()
/*    */       {
/* 51 */         return String.format("Method %s", new Object[] { this.val$desiredDescription.getDisplayName() });
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract boolean shouldRun(Description paramDescription);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract String describe();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void apply(Object child)
/*    */     throws NoTestsRemainException
/*    */   {
/* 76 */     if (!(child instanceof Filterable))
/* 77 */       return;
/* 78 */     Filterable filterable = (Filterable)child;
/* 79 */     filterable.filter(this);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runner/manipulation/Filter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */