package org.junit.runner;

public abstract interface Describable
{
  public abstract Description getDescription();
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runner/Describable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */