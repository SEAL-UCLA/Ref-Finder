/*    */ package org.junit.runner;
/*    */ 
/*    */ import org.junit.runners.Suite;
/*    */ import org.junit.runners.model.InitializationError;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Computer
/*    */ {
/*    */   public static Computer serial()
/*    */   {
/* 17 */     return new Computer();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Runner getSuite(final RunnerBuilder builder, Class<?>[] classes)
/*    */     throws InitializationError
/*    */   {
/* 26 */     new Suite(new RunnerBuilder()
/*    */     {
/*    */ 
/* 29 */       public Runner runnerForClass(Class<?> testClass) throws Throwable { return Computer.this.getRunner(builder, testClass); } }, classes);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Runner getRunner(RunnerBuilder builder, Class<?> testClass)
/*    */     throws Throwable
/*    */   {
/* 38 */     return builder.runnerForClass(testClass);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runner/Computer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */