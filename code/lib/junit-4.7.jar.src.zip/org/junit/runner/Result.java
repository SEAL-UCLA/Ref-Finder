/*     */ package org.junit.runner;
/*     */ 
/*     */ import org.junit.runner.notification.Failure;
/*     */ 
/*     */ public class Result
/*     */ {
/*     */   private int fCount;
/*     */   private int fIgnoreCount;
/*     */   private final java.util.List<Failure> fFailures;
/*     */   private long fRunTime;
/*     */   private long fStartTime;
/*     */   
/*     */   public Result()
/*     */   {
/*  15 */     this.fCount = 0;
/*  16 */     this.fIgnoreCount = 0;
/*  17 */     this.fFailures = new java.util.ArrayList();
/*  18 */     this.fRunTime = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRunCount()
/*     */   {
/*  25 */     return this.fCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFailureCount()
/*     */   {
/*  32 */     return this.fFailures.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getRunTime()
/*     */   {
/*  39 */     return this.fRunTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public java.util.List<Failure> getFailures()
/*     */   {
/*  46 */     return this.fFailures;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getIgnoreCount()
/*     */   {
/*  53 */     return this.fIgnoreCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean wasSuccessful()
/*     */   {
/*  60 */     return getFailureCount() == 0;
/*     */   }
/*     */   
/*     */   private class Listener extends org.junit.runner.notification.RunListener {
/*     */     private Listener() {}
/*     */     
/*  66 */     public void testRunStarted(Description description) throws Exception { Result.this.fStartTime = System.currentTimeMillis(); }
/*     */     
/*     */     public void testRunFinished(Result result)
/*     */       throws Exception
/*     */     {
/*  71 */       long endTime = System.currentTimeMillis();
/*  72 */       Result.access$114(Result.this, endTime - Result.this.fStartTime);
/*     */     }
/*     */     
/*     */     public void testFinished(Description description) throws Exception
/*     */     {
/*  77 */       Result.access$208(Result.this);
/*     */     }
/*     */     
/*     */     public void testFailure(Failure failure) throws Exception
/*     */     {
/*  82 */       Result.this.fFailures.add(failure);
/*     */     }
/*     */     
/*     */     public void testIgnored(Description description) throws Exception
/*     */     {
/*  87 */       Result.access$408(Result.this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void testAssumptionFailure(Failure failure) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public org.junit.runner.notification.RunListener createListener()
/*     */   {
/* 100 */     return new Listener(null);
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runner/Result.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */