/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Description
/*     */ {
/*     */   public static Description createSuiteDescription(String name, Annotation... annotations)
/*     */   {
/*  37 */     if (name.length() == 0)
/*  38 */       throw new IllegalArgumentException("name must have non-zero length");
/*  39 */     return new Description(name, annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createTestDescription(Class<?> clazz, String name, Annotation... annotations)
/*     */   {
/*  51 */     return new Description(String.format("%s(%s)", new Object[] { name, clazz.getName() }), annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createTestDescription(Class<?> clazz, String name)
/*     */   {
/*  63 */     return createTestDescription(clazz, name, new Annotation[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createSuiteDescription(Class<?> testClass)
/*     */   {
/*  72 */     return new Description(testClass.getName(), testClass.getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   public static final Description EMPTY = new Description("No Tests", new Annotation[0]);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   public static final Description TEST_MECHANISM = new Description("Test mechanism", new Annotation[0]);
/*     */   
/*  87 */   private final ArrayList<Description> fChildren = new ArrayList();
/*     */   private final String fDisplayName;
/*     */   private final Annotation[] fAnnotations;
/*     */   
/*     */   private Description(String displayName, Annotation... annotations)
/*     */   {
/*  93 */     this.fDisplayName = displayName;
/*  94 */     this.fAnnotations = annotations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDisplayName()
/*     */   {
/* 101 */     return this.fDisplayName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChild(Description description)
/*     */   {
/* 109 */     getChildren().add(description);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<Description> getChildren()
/*     */   {
/* 116 */     return this.fChildren;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isSuite()
/*     */   {
/* 123 */     return !isTest();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isTest()
/*     */   {
/* 130 */     return getChildren().isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int testCount()
/*     */   {
/* 137 */     if (isTest())
/* 138 */       return 1;
/* 139 */     int result = 0;
/* 140 */     for (Description child : getChildren())
/* 141 */       result += child.testCount();
/* 142 */     return result;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 147 */     return getDisplayName().hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 152 */     if (!(obj instanceof Description))
/* 153 */       return false;
/* 154 */     Description d = (Description)obj;
/* 155 */     return (getDisplayName().equals(d.getDisplayName())) && (getChildren().equals(d.getChildren()));
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 161 */     return getDisplayName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 168 */     return equals(EMPTY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Description childlessCopy()
/*     */   {
/* 176 */     return new Description(this.fDisplayName, this.fAnnotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType)
/*     */   {
/* 184 */     for (Annotation each : this.fAnnotations)
/* 185 */       if (each.annotationType().equals(annotationType))
/* 186 */         return (Annotation)annotationType.cast(each);
/* 187 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<Annotation> getAnnotations()
/*     */   {
/* 194 */     return Arrays.asList(this.fAnnotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getTestClass()
/*     */   {
/* 202 */     String name = getClassName();
/* 203 */     if (name == null)
/* 204 */       return null;
/*     */     try {
/* 206 */       return Class.forName(name);
/*     */     } catch (ClassNotFoundException e) {}
/* 208 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 217 */     Matcher matcher = methodStringMatcher();
/* 218 */     return matcher.matches() ? matcher.group(2) : toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/* 228 */     return parseMethod();
/*     */   }
/*     */   
/*     */   private String parseMethod() {
/* 232 */     Matcher matcher = methodStringMatcher();
/* 233 */     if (matcher.matches())
/* 234 */       return matcher.group(1);
/* 235 */     return null;
/*     */   }
/*     */   
/*     */   private Matcher methodStringMatcher() {
/* 239 */     return Pattern.compile("(.*)\\((.*)\\)").matcher(toString());
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runner/Description.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */