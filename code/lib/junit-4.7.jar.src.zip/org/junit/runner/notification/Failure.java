/*    */ package org.junit.runner.notification;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Failure
/*    */ {
/*    */   private final Description fDescription;
/*    */   private final Throwable fThrownException;
/*    */   
/*    */   public Failure(Description description, Throwable thrownException)
/*    */   {
/* 25 */     this.fThrownException = thrownException;
/* 26 */     this.fDescription = description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getTestHeader()
/*    */   {
/* 33 */     return this.fDescription.getDisplayName();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Description getDescription()
/*    */   {
/* 40 */     return this.fDescription;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Throwable getException()
/*    */   {
/* 48 */     return this.fThrownException;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 53 */     StringBuffer buffer = new StringBuffer();
/* 54 */     buffer.append(getTestHeader() + ": " + this.fThrownException.getMessage());
/* 55 */     return buffer.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getTrace()
/*    */   {
/* 63 */     StringWriter stringWriter = new StringWriter();
/* 64 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 65 */     getException().printStackTrace(writer);
/* 66 */     StringBuffer buffer = stringWriter.getBuffer();
/* 67 */     return buffer.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 75 */     return getException().getMessage();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runner/notification/Failure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */