/*    */ package org.junit.experimental.results;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import org.junit.internal.TextListener;
/*    */ import org.junit.runner.JUnitCore;
/*    */ import org.junit.runner.Result;
/*    */ import org.junit.runner.notification.Failure;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrintableResult
/*    */ {
/*    */   private Result result;
/*    */   
/*    */   public static PrintableResult testResult(Class<?> type)
/*    */   {
/* 26 */     return new PrintableResult(type);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PrintableResult(List<Failure> failures)
/*    */   {
/* 35 */     this(new FailureList(failures).result());
/*    */   }
/*    */   
/*    */   private PrintableResult(Result result) {
/* 39 */     this.result = result;
/*    */   }
/*    */   
/*    */   private PrintableResult(Class<?> type) {
/* 43 */     this(JUnitCore.runClasses(new Class[] { type }));
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 48 */     ByteArrayOutputStream stream = new ByteArrayOutputStream();
/* 49 */     new TextListener(new PrintStream(stream)).testRunFinished(this.result);
/* 50 */     return stream.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int failureCount()
/*    */   {
/* 57 */     return this.result.getFailures().size();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/experimental/results/PrintableResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */