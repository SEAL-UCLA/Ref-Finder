/*    */ package org.junit.experimental.runners;
/*    */ 
/*    */ import org.junit.runners.Suite;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Enclosed
/*    */   extends Suite
/*    */ {
/*    */   public Enclosed(Class<?> klass, RunnerBuilder builder)
/*    */     throws Throwable
/*    */   {
/* 29 */     super(builder, klass, klass.getClasses());
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/experimental/runners/Enclosed.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */