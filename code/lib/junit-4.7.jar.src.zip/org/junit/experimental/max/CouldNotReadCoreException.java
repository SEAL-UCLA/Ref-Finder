/*    */ package org.junit.experimental.max;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CouldNotReadCoreException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */   public CouldNotReadCoreException(Throwable e)
/*    */   {
/* 13 */     super(e);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/experimental/max/CouldNotReadCoreException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */