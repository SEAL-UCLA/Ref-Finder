package org.junit.experimental.theories;

import java.util.List;

public abstract class ParameterSupplier
{
  public abstract List<PotentialAssignment> getValueSources(ParameterSignature paramParameterSignature);
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/experimental/theories/ParameterSupplier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */