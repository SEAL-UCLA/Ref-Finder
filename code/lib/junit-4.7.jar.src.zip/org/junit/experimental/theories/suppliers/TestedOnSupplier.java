/*    */ package org.junit.experimental.theories.suppliers;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.junit.experimental.theories.ParameterSignature;
/*    */ import org.junit.experimental.theories.ParameterSupplier;
/*    */ import org.junit.experimental.theories.PotentialAssignment;
/*    */ 
/*    */ public class TestedOnSupplier
/*    */   extends ParameterSupplier
/*    */ {
/*    */   public List<PotentialAssignment> getValueSources(ParameterSignature sig)
/*    */   {
/* 15 */     List<PotentialAssignment> list = new ArrayList();
/* 16 */     TestedOn testedOn = (TestedOn)sig.getAnnotation(TestedOn.class);
/* 17 */     int[] ints = testedOn.ints();
/* 18 */     for (int i : ints) {
/* 19 */       list.add(PotentialAssignment.forValue(Arrays.asList(new int[][] { ints }).toString(), Integer.valueOf(i)));
/*    */     }
/* 21 */     return list;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/experimental/theories/suppliers/TestedOnSupplier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */