/*     */ package org.junit.experimental.theories;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.junit.Assert;
/*     */ import org.junit.experimental.theories.internal.Assignments;
/*     */ import org.junit.experimental.theories.internal.ParameterizedAssertionError;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runners.BlockJUnit4ClassRunner;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ public class Theories extends BlockJUnit4ClassRunner
/*     */ {
/*     */   public Theories(Class<?> klass) throws InitializationError
/*     */   {
/*  24 */     super(klass);
/*     */   }
/*     */   
/*     */   protected void collectInitializationErrors(List<Throwable> errors)
/*     */   {
/*  29 */     super.collectInitializationErrors(errors);
/*  30 */     validateDataPointFields(errors);
/*     */   }
/*     */   
/*     */   private void validateDataPointFields(List<Throwable> errors) {
/*  34 */     Field[] fields = getTestClass().getJavaClass().getDeclaredFields();
/*     */     
/*  36 */     for (Field each : fields) {
/*  37 */       if ((each.getAnnotation(DataPoint.class) != null) && (!Modifier.isStatic(each.getModifiers())))
/*  38 */         errors.add(new Error("DataPoint field " + each.getName() + " must be static"));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateConstructor(List<Throwable> errors) {
/*  43 */     validateOnlyOneConstructor(errors);
/*     */   }
/*     */   
/*     */   protected void validateTestMethods(List<Throwable> errors)
/*     */   {
/*  48 */     for (FrameworkMethod each : computeTestMethods()) {
/*  49 */       if (each.getAnnotation(Theory.class) != null) {
/*  50 */         each.validatePublicVoid(false, errors);
/*     */       } else
/*  52 */         each.validatePublicVoidNoArg(false, errors);
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<FrameworkMethod> computeTestMethods() {
/*  57 */     List<FrameworkMethod> testMethods = super.computeTestMethods();
/*  58 */     List<FrameworkMethod> theoryMethods = getTestClass().getAnnotatedMethods(Theory.class);
/*  59 */     testMethods.removeAll(theoryMethods);
/*  60 */     testMethods.addAll(theoryMethods);
/*  61 */     return testMethods;
/*     */   }
/*     */   
/*     */   public Statement methodBlock(FrameworkMethod method)
/*     */   {
/*  66 */     return new TheoryAnchor(method);
/*     */   }
/*     */   
/*     */   public class TheoryAnchor extends Statement {
/*  70 */     private int successes = 0;
/*     */     
/*     */     private FrameworkMethod fTestMethod;
/*     */     
/*  74 */     private List<AssumptionViolatedException> fInvalidParameters = new ArrayList();
/*     */     
/*     */     public TheoryAnchor(FrameworkMethod method) {
/*  77 */       this.fTestMethod = method;
/*     */     }
/*     */     
/*     */     public void evaluate() throws Throwable
/*     */     {
/*  82 */       runWithAssignment(Assignments.allUnassigned(this.fTestMethod.getMethod(), Theories.this.getTestClass()));
/*     */       
/*     */ 
/*  85 */       if (this.successes == 0) {
/*  86 */         Assert.fail("Never found parameters that satisfied method assumptions.  Violated assumptions: " + this.fInvalidParameters);
/*     */       }
/*     */     }
/*     */     
/*     */     protected void runWithAssignment(Assignments parameterAssignment)
/*     */       throws Throwable
/*     */     {
/*  93 */       if (!parameterAssignment.isComplete()) {
/*  94 */         runWithIncompleteAssignment(parameterAssignment);
/*     */       } else {
/*  96 */         runWithCompleteAssignment(parameterAssignment);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     protected void runWithIncompleteAssignment(Assignments incomplete)
/*     */       throws InstantiationException, IllegalAccessException, Throwable
/*     */     {
/* 104 */       for (PotentialAssignment source : incomplete.potentialsForNextUnassigned()) {
/* 105 */         runWithAssignment(incomplete.assignNext(source));
/*     */       }
/*     */     }
/*     */     
/*     */     protected void runWithCompleteAssignment(final Assignments complete)
/*     */       throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, Throwable
/*     */     {
/* 112 */       new BlockJUnit4ClassRunner(Theories.this.getTestClass().getJavaClass())
/*     */       {
/*     */         protected void collectInitializationErrors(List<Throwable> errors) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         public Statement methodBlock(FrameworkMethod method)
/*     */         {
/* 121 */           final Statement statement = super.methodBlock(method);
/* 122 */           new Statement()
/*     */           {
/*     */             public void evaluate() throws Throwable {
/*     */               try {
/* 126 */                 statement.evaluate();
/* 127 */                 Theories.TheoryAnchor.this.handleDataPointSuccess();
/*     */               } catch (AssumptionViolatedException e) {
/* 129 */                 Theories.TheoryAnchor.this.handleAssumptionViolation(e);
/*     */               } catch (Throwable e) {
/* 131 */                 Theories.TheoryAnchor.this.reportParameterizedError(e, Theories.TheoryAnchor.1.this.val$complete.getArgumentStrings(Theories.TheoryAnchor.this.nullsOk()));
/*     */               }
/*     */             }
/*     */           };
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         protected Statement methodInvoker(FrameworkMethod method, Object test)
/*     */         {
/* 141 */           return Theories.TheoryAnchor.this.methodCompletesWithParameters(method, complete, test);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 146 */         public Object createTest() throws Exception { return getTestClass().getOnlyConstructor().newInstance(complete.getConstructorArguments(Theories.TheoryAnchor.this.nullsOk())); } }.methodBlock(this.fTestMethod).evaluate();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Statement methodCompletesWithParameters(final FrameworkMethod method, final Assignments complete, final Object freshInstance)
/*     */     {
/* 154 */       new Statement()
/*     */       {
/*     */         public void evaluate() throws Throwable {
/*     */           try {
/* 158 */             Object[] values = complete.getMethodArguments(Theories.TheoryAnchor.this.nullsOk());
/*     */             
/* 160 */             method.invokeExplosively(freshInstance, values);
/*     */           }
/*     */           catch (PotentialAssignment.CouldNotGenerateValueException e) {}
/*     */         }
/*     */       };
/*     */     }
/*     */     
/*     */     protected void handleAssumptionViolation(AssumptionViolatedException e)
/*     */     {
/* 169 */       this.fInvalidParameters.add(e);
/*     */     }
/*     */     
/*     */     protected void reportParameterizedError(Throwable e, Object... params) throws Throwable
/*     */     {
/* 174 */       if (params.length == 0)
/* 175 */         throw e;
/* 176 */       throw new ParameterizedAssertionError(e, this.fTestMethod.getName(), params);
/*     */     }
/*     */     
/*     */     private boolean nullsOk()
/*     */     {
/* 181 */       Theory annotation = (Theory)this.fTestMethod.getMethod().getAnnotation(Theory.class);
/*     */       
/* 183 */       if (annotation == null)
/* 184 */         return false;
/* 185 */       return annotation.nullsAccepted();
/*     */     }
/*     */     
/*     */     protected void handleDataPointSuccess() {
/* 189 */       this.successes += 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/experimental/theories/Theories.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */