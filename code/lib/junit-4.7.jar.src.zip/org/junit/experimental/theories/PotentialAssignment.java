/*   */ package org.junit.experimental.theories;
/*   */ 
/*   */ 
/*   */ 
/*   */ public abstract class PotentialAssignment
/*   */ {
/*   */   public static PotentialAssignment forValue(final String name, Object value)
/*   */   {
/* 9 */     new PotentialAssignment()
/*   */     {
/*   */       public Object getValue() throws PotentialAssignment.CouldNotGenerateValueException {
/* < */         return this.val$value;
/*   */       }
/*   */       
/*   */       public String toString()
/*   */       {
/* A */         return String.format("[%s]", new Object[] { this.val$value });
/*   */       }
/*   */       
/*   */       public String getDescription()
/*   */         throws PotentialAssignment.CouldNotGenerateValueException
/*   */       {
/* G */         return name;
/*   */       }
/*   */     };
/*   */   }
/*   */   
/*   */   public abstract Object getValue()
/*   */     throws PotentialAssignment.CouldNotGenerateValueException;
/*   */   
/*   */   public abstract String getDescription()
/*   */     throws PotentialAssignment.CouldNotGenerateValueException;
/*   */   
/*   */   public static class CouldNotGenerateValueException
/*   */     extends Exception
/*   */   {
/*   */     private static final long serialVersionUID = 1L;
/*   */   }
/*   */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/experimental/theories/PotentialAssignment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */