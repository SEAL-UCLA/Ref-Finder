/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.junit.After;
/*     */ import org.junit.Before;
/*     */ import org.junit.Ignore;
/*     */ import org.junit.Rule;
/*     */ import org.junit.Test;
/*     */ import org.junit.Test.None;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.internal.runners.model.EachTestNotifier;
/*     */ import org.junit.internal.runners.model.ReflectiveCallable;
/*     */ import org.junit.internal.runners.statements.ExpectException;
/*     */ import org.junit.internal.runners.statements.Fail;
/*     */ import org.junit.internal.runners.statements.FailOnTimeout;
/*     */ import org.junit.internal.runners.statements.InvokeMethod;
/*     */ import org.junit.internal.runners.statements.RunAfters;
/*     */ import org.junit.internal.runners.statements.RunBefores;
/*     */ import org.junit.rules.MethodRule;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runners.model.FrameworkField;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockJUnit4ClassRunner
/*     */   extends ParentRunner<FrameworkMethod>
/*     */ {
/*     */   public BlockJUnit4ClassRunner(Class<?> klass)
/*     */     throws InitializationError
/*     */   {
/*  59 */     super(klass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void runChild(FrameworkMethod method, RunNotifier notifier)
/*     */   {
/*  68 */     EachTestNotifier eachNotifier = makeNotifier(method, notifier);
/*  69 */     if (method.getAnnotation(Ignore.class) != null) {
/*  70 */       eachNotifier.fireTestIgnored();
/*  71 */       return;
/*     */     }
/*     */     
/*  74 */     eachNotifier.fireTestStarted();
/*     */     try {
/*  76 */       methodBlock(method).evaluate();
/*     */     } catch (AssumptionViolatedException e) {
/*  78 */       eachNotifier.addFailedAssumption(e);
/*     */     } catch (Throwable e) {
/*  80 */       eachNotifier.addFailure(e);
/*     */     } finally {
/*  82 */       eachNotifier.fireTestFinished();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Description describeChild(FrameworkMethod method)
/*     */   {
/*  88 */     return Description.createTestDescription(getTestClass().getJavaClass(), testName(method), method.getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */   protected List<FrameworkMethod> getChildren()
/*     */   {
/*  94 */     return computeTestMethods();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<FrameworkMethod> computeTestMethods()
/*     */   {
/* 107 */     return getTestClass().getAnnotatedMethods(Test.class);
/*     */   }
/*     */   
/*     */   protected void collectInitializationErrors(List<Throwable> errors)
/*     */   {
/* 112 */     super.collectInitializationErrors(errors);
/*     */     
/* 114 */     validateConstructor(errors);
/* 115 */     validateInstanceMethods(errors);
/* 116 */     validateFields(errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateConstructor(List<Throwable> errors)
/*     */   {
/* 125 */     validateOnlyOneConstructor(errors);
/* 126 */     validateZeroArgConstructor(errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateOnlyOneConstructor(List<Throwable> errors)
/*     */   {
/* 134 */     if (!hasOneConstructor()) {
/* 135 */       String gripe = "Test class should have exactly one public constructor";
/* 136 */       errors.add(new Exception(gripe));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateZeroArgConstructor(List<Throwable> errors)
/*     */   {
/* 146 */     if ((hasOneConstructor()) && (getTestClass().getOnlyConstructor().getParameterTypes().length != 0))
/*     */     {
/* 148 */       String gripe = "Test class should have exactly one public zero-argument constructor";
/* 149 */       errors.add(new Exception(gripe));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean hasOneConstructor() {
/* 154 */     return getTestClass().getJavaClass().getConstructors().length == 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected void validateInstanceMethods(List<Throwable> errors)
/*     */   {
/* 166 */     validatePublicVoidNoArgMethods(After.class, false, errors);
/* 167 */     validatePublicVoidNoArgMethods(Before.class, false, errors);
/* 168 */     validateTestMethods(errors);
/*     */     
/* 170 */     if (computeTestMethods().size() == 0)
/* 171 */       errors.add(new Exception("No runnable methods"));
/*     */   }
/*     */   
/*     */   private void validateFields(List<Throwable> errors) {
/* 175 */     for (FrameworkField each : ruleFields())
/* 176 */       validateRuleField(each.getField(), errors);
/*     */   }
/*     */   
/*     */   private void validateRuleField(Field field, List<Throwable> errors) {
/* 180 */     if (!MethodRule.class.isAssignableFrom(field.getType())) {
/* 181 */       errors.add(new Exception("Field " + field.getName() + " must implement MethodRule"));
/*     */     }
/* 183 */     if (!Modifier.isPublic(field.getModifiers())) {
/* 184 */       errors.add(new Exception("Field " + field.getName() + " must be public"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateTestMethods(List<Throwable> errors)
/*     */   {
/* 193 */     validatePublicVoidNoArgMethods(Test.class, false, errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object createTest()
/*     */     throws Exception
/*     */   {
/* 202 */     return getTestClass().getOnlyConstructor().newInstance(new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String testName(FrameworkMethod method)
/*     */   {
/* 210 */     return method.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement methodBlock(FrameworkMethod method)
/*     */   {
/*     */     Object test;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 248 */       test = new ReflectiveCallable()
/*     */       {
/*     */         protected Object runReflectiveCall() throws Throwable {
/* 251 */           return BlockJUnit4ClassRunner.this.createTest();
/*     */         }
/*     */       }.run();
/*     */     } catch (Throwable e) {
/* 255 */       return new Fail(e);
/*     */     }
/*     */     
/* 258 */     Statement statement = methodInvoker(method, test);
/* 259 */     statement = possiblyExpectingExceptions(method, test, statement);
/* 260 */     statement = withPotentialTimeout(method, test, statement);
/* 261 */     statement = withRules(method, test, statement);
/* 262 */     statement = withBefores(method, test, statement);
/* 263 */     statement = withAfters(method, test, statement);
/* 264 */     return statement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement methodInvoker(FrameworkMethod method, Object test)
/*     */   {
/* 275 */     return new InvokeMethod(method, test);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement possiblyExpectingExceptions(FrameworkMethod method, Object test, Statement next)
/*     */   {
/* 289 */     Test annotation = (Test)method.getAnnotation(Test.class);
/* 290 */     return expectsException(annotation) ? new ExpectException(next, getExpectedException(annotation)) : next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement withPotentialTimeout(FrameworkMethod method, Object test, Statement next)
/*     */   {
/* 304 */     long timeout = getTimeout((Test)method.getAnnotation(Test.class));
/* 305 */     return timeout > 0L ? new FailOnTimeout(next, timeout) : next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement withBefores(FrameworkMethod method, Object target, Statement statement)
/*     */   {
/* 318 */     List<FrameworkMethod> befores = getTestClass().getAnnotatedMethods(Before.class);
/* 319 */     return befores.isEmpty() ? statement : new RunBefores(statement, befores, target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement withAfters(FrameworkMethod method, Object target, Statement statement)
/*     */   {
/* 335 */     List<FrameworkMethod> afters = getTestClass().getAnnotatedMethods(After.class);
/* 336 */     return afters.isEmpty() ? statement : new RunAfters(statement, afters, target);
/*     */   }
/*     */   
/*     */ 
/*     */   private Statement withRules(FrameworkMethod method, Object target, Statement statement)
/*     */   {
/* 342 */     Statement result = statement;
/* 343 */     for (MethodRule each : rules(target))
/* 344 */       result = each.apply(result, method, target);
/* 345 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<MethodRule> rules(Object test)
/*     */   {
/* 353 */     List<MethodRule> results = new ArrayList();
/* 354 */     for (FrameworkField each : ruleFields())
/* 355 */       results.add(createRule(test, each));
/* 356 */     return results;
/*     */   }
/*     */   
/*     */   private List<FrameworkField> ruleFields() {
/* 360 */     return getTestClass().getAnnotatedFields(Rule.class);
/*     */   }
/*     */   
/*     */   private MethodRule createRule(Object test, FrameworkField each)
/*     */   {
/*     */     try {
/* 366 */       return (MethodRule)each.get(test);
/*     */     } catch (IllegalAccessException e) {
/* 368 */       throw new RuntimeException("How did getFields return a field we couldn't access?");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private EachTestNotifier makeNotifier(FrameworkMethod method, RunNotifier notifier)
/*     */   {
/* 375 */     Description description = describeChild(method);
/* 376 */     return new EachTestNotifier(notifier, description);
/*     */   }
/*     */   
/*     */   private Class<? extends Throwable> getExpectedException(Test annotation) {
/* 380 */     if ((annotation == null) || (annotation.expected() == Test.None.class)) {
/* 381 */       return null;
/*     */     }
/* 383 */     return annotation.expected();
/*     */   }
/*     */   
/*     */   private boolean expectsException(Test annotation) {
/* 387 */     return getExpectedException(annotation) != null;
/*     */   }
/*     */   
/*     */   private long getTimeout(Test annotation) {
/* 391 */     if (annotation == null)
/* 392 */       return 0L;
/* 393 */     return annotation.timeout();
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/BlockJUnit4ClassRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */