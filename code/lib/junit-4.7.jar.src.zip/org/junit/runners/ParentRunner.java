/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.junit.AfterClass;
/*     */ import org.junit.BeforeClass;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.internal.runners.model.EachTestNotifier;
/*     */ import org.junit.internal.runners.statements.RunAfters;
/*     */ import org.junit.internal.runners.statements.RunBefores;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.Filterable;
/*     */ import org.junit.runner.manipulation.NoTestsRemainException;
/*     */ import org.junit.runner.manipulation.Sortable;
/*     */ import org.junit.runner.manipulation.Sorter;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runner.notification.StoppedByUserException;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.RunnerScheduler;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParentRunner<T>
/*     */   extends Runner
/*     */   implements Filterable, Sortable
/*     */ {
/*     */   private final TestClass fTestClass;
/*  46 */   private Filter fFilter = null;
/*     */   
/*  48 */   private Sorter fSorter = Sorter.NULL;
/*     */   
/*  50 */   private RunnerScheduler fScheduler = new RunnerScheduler() {
/*     */     public void schedule(Runnable childStatement) {
/*  52 */       childStatement.run();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void finished() {}
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */   protected ParentRunner(Class<?> testClass)
/*     */     throws InitializationError
/*     */   {
/*  65 */     this.fTestClass = new TestClass(testClass);
/*  66 */     validate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract List<T> getChildren();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Description describeChild(T paramT);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void runChild(T paramT, RunNotifier paramRunNotifier);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void collectInitializationErrors(List<Throwable> errors)
/*     */   {
/* 103 */     validatePublicVoidNoArgMethods(BeforeClass.class, true, errors);
/* 104 */     validatePublicVoidNoArgMethods(AfterClass.class, true, errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validatePublicVoidNoArgMethods(Class<? extends Annotation> annotation, boolean isStatic, List<Throwable> errors)
/*     */   {
/* 119 */     List<FrameworkMethod> methods = getTestClass().getAnnotatedMethods(annotation);
/*     */     
/* 121 */     for (FrameworkMethod eachTestMethod : methods) {
/* 122 */       eachTestMethod.validatePublicVoidNoArg(isStatic, errors);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement classBlock(RunNotifier notifier)
/*     */   {
/* 143 */     Statement statement = childrenInvoker(notifier);
/* 144 */     statement = withBeforeClasses(statement);
/* 145 */     statement = withAfterClasses(statement);
/* 146 */     return statement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement withBeforeClasses(Statement statement)
/*     */   {
/* 155 */     List<FrameworkMethod> befores = this.fTestClass.getAnnotatedMethods(BeforeClass.class);
/*     */     
/* 157 */     return befores.isEmpty() ? statement : new RunBefores(statement, befores, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement withAfterClasses(Statement statement)
/*     */   {
/* 169 */     List<FrameworkMethod> afters = this.fTestClass.getAnnotatedMethods(AfterClass.class);
/*     */     
/* 171 */     return afters.isEmpty() ? statement : new RunAfters(statement, afters, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement childrenInvoker(final RunNotifier notifier)
/*     */   {
/* 181 */     new Statement()
/*     */     {
/*     */       public void evaluate() {
/* 184 */         ParentRunner.this.runChildren(notifier);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private void runChildren(final RunNotifier notifier) {
/* 190 */     for (final T each : getFilteredChildren())
/* 191 */       this.fScheduler.schedule(new Runnable() {
/*     */         public void run() {
/* 193 */           ParentRunner.this.runChild(each, notifier);
/*     */         }
/*     */       });
/* 196 */     this.fScheduler.finished();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getName()
/*     */   {
/* 203 */     return this.fTestClass.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final TestClass getTestClass()
/*     */   {
/* 214 */     return this.fTestClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Description getDescription()
/*     */   {
/* 223 */     Description description = Description.createSuiteDescription(getName(), this.fTestClass.getAnnotations());
/*     */     
/* 225 */     for (T child : getFilteredChildren())
/* 226 */       description.addChild(describeChild(child));
/* 227 */     return description;
/*     */   }
/*     */   
/*     */   public void run(RunNotifier notifier)
/*     */   {
/* 232 */     EachTestNotifier testNotifier = new EachTestNotifier(notifier, getDescription());
/*     */     try
/*     */     {
/* 235 */       Statement statement = classBlock(notifier);
/* 236 */       statement.evaluate();
/*     */     } catch (AssumptionViolatedException e) {
/* 238 */       testNotifier.fireTestIgnored();
/*     */     } catch (StoppedByUserException e) {
/* 240 */       throw e;
/*     */     } catch (Throwable e) {
/* 242 */       testNotifier.addFailure(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void filter(Filter filter)
/*     */     throws NoTestsRemainException
/*     */   {
/* 251 */     this.fFilter = filter;
/*     */     
/* 253 */     for (T each : getChildren())
/* 254 */       if (shouldRun(each))
/* 255 */         return;
/* 256 */     throw new NoTestsRemainException();
/*     */   }
/*     */   
/*     */   public void sort(Sorter sorter) {
/* 260 */     this.fSorter = sorter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void validate()
/*     */     throws InitializationError
/*     */   {
/* 268 */     List<Throwable> errors = new ArrayList();
/* 269 */     collectInitializationErrors(errors);
/* 270 */     if (!errors.isEmpty())
/* 271 */       throw new InitializationError(errors);
/*     */   }
/*     */   
/*     */   private List<T> getFilteredChildren() {
/* 275 */     ArrayList<T> filtered = new ArrayList();
/* 276 */     for (T each : getChildren()) {
/* 277 */       if (shouldRun(each)) {
/*     */         try {
/* 279 */           filterChild(each);
/* 280 */           sortChild(each);
/* 281 */           filtered.add(each);
/*     */         } catch (NoTestsRemainException e) {}
/*     */       }
/*     */     }
/* 285 */     Collections.sort(filtered, comparator());
/* 286 */     return filtered;
/*     */   }
/*     */   
/*     */   private void sortChild(T child) {
/* 290 */     this.fSorter.apply(child);
/*     */   }
/*     */   
/*     */   private void filterChild(T child) throws NoTestsRemainException {
/* 294 */     if (this.fFilter != null)
/* 295 */       this.fFilter.apply(child);
/*     */   }
/*     */   
/*     */   private boolean shouldRun(T each) {
/* 299 */     return (this.fFilter == null) || (this.fFilter.shouldRun(describeChild(each)));
/*     */   }
/*     */   
/*     */   private Comparator<? super T> comparator() {
/* 303 */     new Comparator() {
/*     */       public int compare(T o1, T o2) {
/* 305 */         return ParentRunner.this.fSorter.compare(ParentRunner.this.describeChild(o1), ParentRunner.this.describeChild(o2));
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScheduler(RunnerScheduler scheduler)
/*     */   {
/* 315 */     this.fScheduler = scheduler;
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/ParentRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */