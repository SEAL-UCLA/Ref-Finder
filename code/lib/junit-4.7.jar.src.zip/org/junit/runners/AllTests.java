/*    */ package org.junit.runners;
/*    */ 
/*    */ import org.junit.internal.runners.SuiteMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllTests
/*    */   extends SuiteMethod
/*    */ {
/*    */   public AllTests(Class<?> klass)
/*    */     throws Throwable
/*    */   {
/* 22 */     super(klass);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/AllTests.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */