/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parameterized
/*     */   extends Suite
/*     */ {
/*     */   private class TestClassRunnerForParameters
/*     */     extends BlockJUnit4ClassRunner
/*     */   {
/*     */     private final int fParameterSetNumber;
/*     */     private final List<Object[]> fParameterList;
/*     */     
/*     */     TestClassRunnerForParameters(List<Object[]> type, int parameterList)
/*     */       throws InitializationError
/*     */     {
/*  79 */       super();
/*  80 */       this.fParameterList = parameterList;
/*  81 */       this.fParameterSetNumber = i;
/*     */     }
/*     */     
/*     */     public Object createTest() throws Exception
/*     */     {
/*  86 */       return getTestClass().getOnlyConstructor().newInstance(computeParams());
/*     */     }
/*     */     
/*     */     private Object[] computeParams() throws Exception
/*     */     {
/*     */       try {
/*  92 */         return (Object[])this.fParameterList.get(this.fParameterSetNumber);
/*     */       } catch (ClassCastException e) {
/*  94 */         throw new Exception(String.format("%s.%s() must return a Collection of arrays.", new Object[] { getTestClass().getName(), Parameterized.this.getParametersMethod(getTestClass()).getName() }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected String getName()
/*     */     {
/* 103 */       return String.format("[%s]", new Object[] { Integer.valueOf(this.fParameterSetNumber) });
/*     */     }
/*     */     
/*     */     protected String testName(FrameworkMethod method)
/*     */     {
/* 108 */       return String.format("%s[%s]", new Object[] { method.getName(), Integer.valueOf(this.fParameterSetNumber) });
/*     */     }
/*     */     
/*     */ 
/*     */     protected void validateConstructor(List<Throwable> errors)
/*     */     {
/* 114 */       validateOnlyOneConstructor(errors);
/*     */     }
/*     */     
/*     */     protected Statement classBlock(RunNotifier notifier)
/*     */     {
/* 119 */       return childrenInvoker(notifier);
/*     */     }
/*     */   }
/*     */   
/* 123 */   private final ArrayList<Runner> runners = new ArrayList();
/*     */   
/*     */ 
/*     */   public Parameterized(Class<?> klass)
/*     */     throws Throwable
/*     */   {
/* 129 */     super(klass, Collections.emptyList());
/* 130 */     List<Object[]> parametersList = getParametersList(getTestClass());
/* 131 */     for (int i = 0; i < parametersList.size(); i++) {
/* 132 */       this.runners.add(new TestClassRunnerForParameters(getTestClass().getJavaClass(), parametersList, i));
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<Runner> getChildren()
/*     */   {
/* 138 */     return this.runners;
/*     */   }
/*     */   
/*     */   private List<Object[]> getParametersList(TestClass klass)
/*     */     throws Throwable
/*     */   {
/* 144 */     return (List)getParametersMethod(klass).invokeExplosively(null, new Object[0]);
/*     */   }
/*     */   
/*     */   private FrameworkMethod getParametersMethod(TestClass testClass)
/*     */     throws Exception
/*     */   {
/* 150 */     List<FrameworkMethod> methods = testClass.getAnnotatedMethods(Parameters.class);
/*     */     
/* 152 */     for (FrameworkMethod each : methods) {
/* 153 */       int modifiers = each.getMethod().getModifiers();
/* 154 */       if ((Modifier.isStatic(modifiers)) && (Modifier.isPublic(modifiers))) {
/* 155 */         return each;
/*     */       }
/*     */     }
/* 158 */     throw new Exception("No public static parameters method on class " + testClass.getName());
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   @Target({java.lang.annotation.ElementType.METHOD})
/*     */   public static @interface Parameters {}
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/Parameterized.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */