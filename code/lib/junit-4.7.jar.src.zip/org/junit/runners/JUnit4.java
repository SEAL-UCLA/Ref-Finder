/*    */ package org.junit.runners;
/*    */ 
/*    */ import org.junit.runners.model.InitializationError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JUnit4
/*    */   extends BlockJUnit4ClassRunner
/*    */ {
/*    */   public JUnit4(Class<?> klass)
/*    */     throws InitializationError
/*    */   {
/* 20 */     super(klass);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/JUnit4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */