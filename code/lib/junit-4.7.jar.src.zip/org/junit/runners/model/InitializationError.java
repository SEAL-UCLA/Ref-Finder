/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InitializationError
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final List<Throwable> fErrors;
/*    */   
/*    */   public InitializationError(List<Throwable> errors)
/*    */   {
/* 18 */     this.fErrors = errors;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public InitializationError(String string)
/*    */   {
/* 26 */     this(Arrays.asList(new Throwable[] { new Exception(string) }));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<Throwable> getCauses()
/*    */   {
/* 33 */     return this.fErrors;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/model/InitializationError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */