/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ abstract class FrameworkMember<T extends FrameworkMember<T>>
/*    */ {
/*    */   abstract Annotation[] getAnnotations();
/*    */   
/*    */   abstract boolean isShadowedBy(T paramT);
/*    */   
/*    */   boolean isShadowedBy(List<T> members)
/*    */   {
/* 15 */     for (T each : members)
/* 16 */       if (isShadowedBy(each))
/* 17 */         return true;
/* 18 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/model/FrameworkMember.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */