package org.junit.runners.model;

public abstract interface RunnerScheduler
{
  public abstract void schedule(Runnable paramRunnable);
  
  public abstract void finished();
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/model/RunnerScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */