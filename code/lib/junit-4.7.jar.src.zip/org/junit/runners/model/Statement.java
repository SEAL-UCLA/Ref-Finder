package org.junit.runners.model;

public abstract class Statement
{
  public abstract void evaluate()
    throws Throwable;
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/model/Statement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */