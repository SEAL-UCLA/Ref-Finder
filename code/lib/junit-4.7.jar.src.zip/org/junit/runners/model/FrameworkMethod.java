/*     */ package org.junit.runners.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.List;
/*     */ import org.junit.internal.runners.model.ReflectiveCallable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameworkMethod
/*     */   extends FrameworkMember<FrameworkMethod>
/*     */ {
/*     */   final Method fMethod;
/*     */   
/*     */   public FrameworkMethod(Method method)
/*     */   {
/*  24 */     this.fMethod = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/*  31 */     return this.fMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invokeExplosively(final Object target, final Object... params)
/*     */     throws Throwable
/*     */   {
/*  41 */     new ReflectiveCallable()
/*     */     {
/*     */       protected Object runReflectiveCall() throws Throwable {
/*  44 */         return FrameworkMethod.this.fMethod.invoke(target, params);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  53 */     return this.fMethod.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validatePublicVoidNoArg(boolean isStatic, List<Throwable> errors)
/*     */   {
/*  66 */     validatePublicVoid(isStatic, errors);
/*  67 */     if (this.fMethod.getParameterTypes().length != 0) {
/*  68 */       errors.add(new Exception("Method " + this.fMethod.getName() + " should have no parameters"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validatePublicVoid(boolean isStatic, List<Throwable> errors)
/*     */   {
/*  81 */     if (Modifier.isStatic(this.fMethod.getModifiers()) != isStatic) {
/*  82 */       String state = isStatic ? "should" : "should not";
/*  83 */       errors.add(new Exception("Method " + this.fMethod.getName() + "() " + state + " be static"));
/*     */     }
/*  85 */     if (!Modifier.isPublic(this.fMethod.getDeclaringClass().getModifiers()))
/*  86 */       errors.add(new Exception("Class " + this.fMethod.getDeclaringClass().getName() + " should be public"));
/*  87 */     if (!Modifier.isPublic(this.fMethod.getModifiers()))
/*  88 */       errors.add(new Exception("Method " + this.fMethod.getName() + "() should be public"));
/*  89 */     if (this.fMethod.getReturnType() != Void.TYPE) {
/*  90 */       errors.add(new Exception("Method " + this.fMethod.getName() + "() should be void"));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isShadowedBy(FrameworkMethod other) {
/*  95 */     if (!other.getName().equals(getName()))
/*  96 */       return false;
/*  97 */     if (other.getParameterTypes().length != getParameterTypes().length)
/*  98 */       return false;
/*  99 */     for (int i = 0; i < other.getParameterTypes().length; i++)
/* 100 */       if (!other.getParameterTypes()[i].equals(getParameterTypes()[i]))
/* 101 */         return false;
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 107 */     if (!FrameworkMethod.class.isInstance(obj))
/* 108 */       return false;
/* 109 */     return ((FrameworkMethod)obj).fMethod.equals(this.fMethod);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 114 */     return this.fMethod.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean producesType(Class<?> type)
/*     */   {
/* 122 */     return (getParameterTypes().length == 0) && (type.isAssignableFrom(this.fMethod.getReturnType()));
/*     */   }
/*     */   
/*     */   private Class<?>[] getParameterTypes()
/*     */   {
/* 127 */     return this.fMethod.getParameterTypes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 135 */     return this.fMethod.getAnnotations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType)
/*     */   {
/* 143 */     return this.fMethod.getAnnotation(annotationType);
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/model/FrameworkMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */