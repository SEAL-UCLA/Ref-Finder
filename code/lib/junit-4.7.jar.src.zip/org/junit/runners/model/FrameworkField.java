/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FrameworkField
/*    */   extends FrameworkMember<FrameworkField>
/*    */ {
/*    */   private final Field fField;
/*    */   
/*    */   FrameworkField(Field field)
/*    */   {
/* 16 */     this.fField = field;
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations()
/*    */   {
/* 21 */     return this.fField.getAnnotations();
/*    */   }
/*    */   
/*    */   public boolean isShadowedBy(FrameworkField otherMember)
/*    */   {
/* 26 */     return otherMember.getField().getName().equals(getField().getName());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Field getField()
/*    */   {
/* 33 */     return this.fField;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object get(Object target)
/*    */     throws IllegalArgumentException, IllegalAccessException
/*    */   {
/* 40 */     return this.fField.get(target);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/model/FrameworkField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */