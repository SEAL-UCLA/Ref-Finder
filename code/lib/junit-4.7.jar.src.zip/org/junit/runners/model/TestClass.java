/*     */ package org.junit.runners.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.junit.Assert;
/*     */ import org.junit.Before;
/*     */ import org.junit.BeforeClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestClass
/*     */ {
/*     */   private final Class<?> fClass;
/*  22 */   private Map<Class<?>, List<FrameworkMethod>> fMethodsForAnnotations = new HashMap();
/*  23 */   private Map<Class<?>, List<FrameworkField>> fFieldsForAnnotations = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestClass(Class<?> klass)
/*     */   {
/*  32 */     this.fClass = klass;
/*  33 */     if ((klass != null) && (klass.getConstructors().length > 1)) {
/*  34 */       throw new IllegalArgumentException("Test class can only have one constructor");
/*     */     }
/*     */     
/*  37 */     for (Class<?> eachClass : getSuperClasses(this.fClass)) {
/*  38 */       for (Method eachMethod : eachClass.getDeclaredMethods())
/*  39 */         addToAnnotationLists(new FrameworkMethod(eachMethod), this.fMethodsForAnnotations);
/*  40 */       for (Field eachField : eachClass.getDeclaredFields())
/*  41 */         addToAnnotationLists(new FrameworkField(eachField), this.fFieldsForAnnotations);
/*     */     }
/*     */   }
/*     */   
/*     */   private <T extends FrameworkMember<T>> void addToAnnotationLists(T member, Map<Class<?>, List<T>> map) {
/*  46 */     for (Annotation each : member.getAnnotations()) {
/*  47 */       Class<? extends Annotation> type = each.annotationType();
/*  48 */       List<T> members = getAnnotatedMembers(map, type);
/*  49 */       if (member.isShadowedBy(members))
/*  50 */         return;
/*  51 */       if (runsTopToBottom(type)) {
/*  52 */         members.add(0, member);
/*     */       } else {
/*  54 */         members.add(member);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<FrameworkMethod> getAnnotatedMethods(Class<? extends Annotation> annotationClass)
/*     */   {
/*  64 */     return getAnnotatedMembers(this.fMethodsForAnnotations, annotationClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<FrameworkField> getAnnotatedFields(Class<? extends Annotation> annotationClass)
/*     */   {
/*  72 */     return getAnnotatedMembers(this.fFieldsForAnnotations, annotationClass);
/*     */   }
/*     */   
/*     */   private <T> List<T> getAnnotatedMembers(Map<Class<?>, List<T>> map, Class<? extends Annotation> type)
/*     */   {
/*  77 */     if (!map.containsKey(type))
/*  78 */       map.put(type, new ArrayList());
/*  79 */     return (List)map.get(type);
/*     */   }
/*     */   
/*     */   private boolean runsTopToBottom(Class<? extends Annotation> annotation) {
/*  83 */     return (annotation.equals(Before.class)) || (annotation.equals(BeforeClass.class));
/*     */   }
/*     */   
/*     */   private List<Class<?>> getSuperClasses(Class<?> testClass)
/*     */   {
/*  88 */     ArrayList<Class<?>> results = new ArrayList();
/*  89 */     Class<?> current = testClass;
/*  90 */     while (current != null) {
/*  91 */       results.add(current);
/*  92 */       current = current.getSuperclass();
/*     */     }
/*  94 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getJavaClass()
/*     */   {
/* 101 */     return this.fClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 108 */     if (this.fClass == null)
/* 109 */       return "null";
/* 110 */     return this.fClass.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Constructor<?> getOnlyConstructor()
/*     */   {
/* 119 */     Constructor<?>[] constructors = this.fClass.getConstructors();
/* 120 */     Assert.assertEquals(1L, constructors.length);
/* 121 */     return constructors[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 128 */     if (this.fClass == null)
/* 129 */       return new Annotation[0];
/* 130 */     return this.fClass.getAnnotations();
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/runners/model/TestClass.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */