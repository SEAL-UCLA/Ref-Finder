/*    */ package org.junit.rules;
/*    */ 
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestWatchman
/*    */   implements MethodRule
/*    */ {
/*    */   public Statement apply(final Statement base, final FrameworkMethod method, Object target)
/*    */   {
/* 43 */     new Statement()
/*    */     {
/*    */       public void evaluate() throws Throwable {
/* 46 */         TestWatchman.this.starting(method);
/*    */         try {
/* 48 */           base.evaluate();
/* 49 */           TestWatchman.this.succeeded(method);
/*    */         } catch (Throwable t) {
/* 51 */           TestWatchman.this.failed(t, method);
/* 52 */           throw t;
/*    */         } finally {
/* 54 */           TestWatchman.this.finished(method);
/*    */         }
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public void succeeded(FrameworkMethod method) {}
/*    */   
/*    */   public void failed(Throwable e, FrameworkMethod method) {}
/*    */   
/*    */   public void starting(FrameworkMethod method) {}
/*    */   
/*    */   public void finished(FrameworkMethod method) {}
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/rules/TestWatchman.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */