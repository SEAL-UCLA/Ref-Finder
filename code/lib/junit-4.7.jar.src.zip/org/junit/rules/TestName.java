/*    */ package org.junit.rules;
/*    */ 
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestName
/*    */   extends TestWatchman
/*    */ {
/*    */   private String fName;
/*    */   
/*    */   public void starting(FrameworkMethod method)
/*    */   {
/* 30 */     this.fName = method.getName();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getMethodName()
/*    */   {
/* 37 */     return this.fName;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/rules/TestName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */