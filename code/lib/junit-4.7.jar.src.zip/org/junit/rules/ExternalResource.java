/*    */ package org.junit.rules;
/*    */ 
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ExternalResource
/*    */   implements MethodRule
/*    */ {
/*    */   public final Statement apply(final Statement base, FrameworkMethod method, Object target)
/*    */   {
/* 38 */     new Statement()
/*    */     {
/*    */       public void evaluate() throws Throwable {
/* 41 */         ExternalResource.this.before();
/*    */         try {
/* 43 */           base.evaluate();
/*    */         } finally {
/* 45 */           ExternalResource.this.after();
/*    */         }
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   protected void before()
/*    */     throws Throwable
/*    */   {}
/*    */   
/*    */   protected void after() {}
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/rules/ExternalResource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */