/*    */ package org.junit.rules;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.hamcrest.Matcher;
/*    */ import org.junit.Assert;
/*    */ import org.junit.internal.runners.model.MultipleFailureException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorCollector
/*    */   extends Verifier
/*    */ {
/* 36 */   private List<Throwable> errors = new ArrayList();
/*    */   
/*    */   protected void verify() throws Throwable
/*    */   {
/* 40 */     MultipleFailureException.assertEmpty(this.errors);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void addError(Throwable error)
/*    */   {
/* 47 */     this.errors.add(error);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public <T> void checkThat(final T value, final Matcher<T> matcher)
/*    */   {
/* 55 */     checkSucceeds(new Callable() {
/*    */       public Object call() throws Exception {
/* 57 */         Assert.assertThat(value, matcher);
/* 58 */         return value;
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object checkSucceeds(Callable<Object> callable)
/*    */   {
/*    */     try
/*    */     {
/* 70 */       return callable.call();
/*    */     } catch (Throwable e) {
/* 72 */       addError(e); }
/* 73 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/rules/ErrorCollector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */