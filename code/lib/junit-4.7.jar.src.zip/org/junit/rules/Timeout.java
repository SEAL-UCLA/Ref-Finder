/*    */ package org.junit.rules;
/*    */ 
/*    */ import org.junit.internal.runners.statements.FailOnTimeout;
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Timeout
/*    */   implements MethodRule
/*    */ {
/*    */   private final int fMillis;
/*    */   
/*    */   public Timeout(int millis)
/*    */   {
/* 43 */     this.fMillis = millis;
/*    */   }
/*    */   
/*    */   public Statement apply(Statement base, FrameworkMethod method, Object target) {
/* 47 */     return new FailOnTimeout(base, this.fMillis);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/rules/Timeout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */