/*    */ package org.junit.rules;
/*    */ 
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Verifier
/*    */   implements MethodRule
/*    */ {
/*    */   public Statement apply(final Statement base, FrameworkMethod method, Object target)
/*    */   {
/* 31 */     new Statement()
/*    */     {
/*    */       public void evaluate() throws Throwable {
/* 34 */         base.evaluate();
/* 35 */         Verifier.this.verify();
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   protected void verify()
/*    */     throws Throwable
/*    */   {}
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/rules/Verifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */