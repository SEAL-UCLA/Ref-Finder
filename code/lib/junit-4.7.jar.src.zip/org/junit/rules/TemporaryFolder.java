/*    */ package org.junit.rules;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemporaryFolder
/*    */   extends ExternalResource
/*    */ {
/*    */   private File folder;
/*    */   
/*    */   protected void before()
/*    */     throws Throwable
/*    */   {
/* 32 */     create();
/*    */   }
/*    */   
/*    */   protected void after()
/*    */   {
/* 37 */     delete();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void create()
/*    */     throws IOException
/*    */   {
/* 45 */     this.folder = File.createTempFile("junit", "");
/* 46 */     this.folder.delete();
/* 47 */     this.folder.mkdir();
/*    */   }
/*    */   
/*    */ 
/*    */   public File newFile(String fileName)
/*    */     throws IOException
/*    */   {
/* 54 */     File file = new File(this.folder, fileName);
/* 55 */     file.createNewFile();
/* 56 */     return file;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public File newFolder(String folderName)
/*    */   {
/* 63 */     File file = new File(this.folder, folderName);
/* 64 */     file.mkdir();
/* 65 */     return file;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public File getRoot()
/*    */   {
/* 72 */     return this.folder;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void delete()
/*    */   {
/* 81 */     recursiveDelete(this.folder);
/*    */   }
/*    */   
/*    */   private void recursiveDelete(File file) {
/* 85 */     File[] files = file.listFiles();
/* 86 */     if (files != null)
/* 87 */       for (File each : files)
/* 88 */         recursiveDelete(each);
/* 89 */     file.delete();
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/rules/TemporaryFolder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */