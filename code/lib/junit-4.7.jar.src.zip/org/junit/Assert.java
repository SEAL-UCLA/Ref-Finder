/*     */ package org.junit;
/*     */ 
/*     */ import org.hamcrest.Description;
/*     */ import org.hamcrest.Matcher;
/*     */ import org.hamcrest.StringDescription;
/*     */ import org.junit.internal.ArrayComparisonFailure;
/*     */ import org.junit.internal.ExactComparisonCriteria;
/*     */ import org.junit.internal.InexactComparisonCriteria;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assert
/*     */ {
/*     */   public static void assertTrue(String message, boolean condition)
/*     */   {
/*  42 */     if (!condition) {
/*  43 */       fail(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertTrue(boolean condition)
/*     */   {
/*  54 */     assertTrue(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertFalse(String message, boolean condition)
/*     */   {
/*  68 */     assertTrue(message, !condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertFalse(boolean condition)
/*     */   {
/*  79 */     assertFalse(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fail(String message)
/*     */   {
/*  91 */     throw new AssertionError(message == null ? "" : message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void fail()
/*     */   {
/*  98 */     fail(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, Object expected, Object actual)
/*     */   {
/* 117 */     if ((expected == null) && (actual == null))
/* 118 */       return;
/* 119 */     if ((expected != null) && (isEquals(expected, actual)))
/* 120 */       return;
/* 121 */     if (((expected instanceof String)) && ((actual instanceof String))) {
/* 122 */       String cleanMessage = message == null ? "" : message;
/* 123 */       throw new ComparisonFailure(cleanMessage, (String)expected, (String)actual);
/*     */     }
/*     */     
/* 126 */     failNotEquals(message, expected, actual);
/*     */   }
/*     */   
/*     */   private static boolean isEquals(Object expected, Object actual) {
/* 130 */     return expected.equals(actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(Object expected, Object actual)
/*     */   {
/* 145 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, Object[] expecteds, Object[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 166 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(Object[] expecteds, Object[] actuals)
/*     */   {
/* 183 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, byte[] expecteds, byte[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 200 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(byte[] expecteds, byte[] actuals)
/*     */   {
/* 213 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, char[] expecteds, char[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 230 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(char[] expecteds, char[] actuals)
/*     */   {
/* 243 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, short[] expecteds, short[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 260 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(short[] expecteds, short[] actuals)
/*     */   {
/* 273 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, int[] expecteds, int[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 290 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(int[] expecteds, int[] actuals)
/*     */   {
/* 303 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, long[] expecteds, long[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 320 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(long[] expecteds, long[] actuals)
/*     */   {
/* 333 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, double[] expecteds, double[] actuals, double delta)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 350 */     new InexactComparisonCriteria(delta).arrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(double[] expecteds, double[] actuals, double delta)
/*     */   {
/* 363 */     assertArrayEquals(null, expecteds, actuals, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, float[] expecteds, float[] actuals, float delta)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 380 */     new InexactComparisonCriteria(delta).arrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(float[] expecteds, float[] actuals, float delta)
/*     */   {
/* 393 */     assertArrayEquals(null, expecteds, actuals, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void internalArrayEquals(String message, Object expecteds, Object actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 414 */     new ExactComparisonCriteria().arrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, double expected, double actual, double delta)
/*     */   {
/* 438 */     if (Double.compare(expected, actual) == 0)
/* 439 */       return;
/* 440 */     if (Math.abs(expected - actual) > delta) {
/* 441 */       failNotEquals(message, new Double(expected), new Double(actual));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(long expected, long actual)
/*     */   {
/* 454 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, long expected, long actual)
/*     */   {
/* 470 */     assertEquals(message, Long.valueOf(expected), Long.valueOf(actual));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(double expected, double actual)
/*     */   {
/* 480 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(String message, double expected, double actual)
/*     */   {
/* 491 */     fail("Use assertEquals(expected, actual, delta) to compare floating-point numbers");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(double expected, double actual, double delta)
/*     */   {
/* 510 */     assertEquals(null, expected, actual, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(String message, Object object)
/*     */   {
/* 524 */     assertTrue(message, object != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(Object object)
/*     */   {
/* 535 */     assertNotNull(null, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNull(String message, Object object)
/*     */   {
/* 549 */     assertTrue(message, object == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNull(Object object)
/*     */   {
/* 560 */     assertNull(null, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertSame(String message, Object expected, Object actual)
/*     */   {
/* 576 */     if (expected == actual)
/* 577 */       return;
/* 578 */     failNotSame(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertSame(Object expected, Object actual)
/*     */   {
/* 591 */     assertSame(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotSame(String message, Object unexpected, Object actual)
/*     */   {
/* 609 */     if (unexpected == actual) {
/* 610 */       failSame(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotSame(Object unexpected, Object actual)
/*     */   {
/* 624 */     assertNotSame(null, unexpected, actual);
/*     */   }
/*     */   
/*     */   private static void failSame(String message) {
/* 628 */     String formatted = "";
/* 629 */     if (message != null)
/* 630 */       formatted = message + " ";
/* 631 */     fail(formatted + "expected not same");
/*     */   }
/*     */   
/*     */   private static void failNotSame(String message, Object expected, Object actual)
/*     */   {
/* 636 */     String formatted = "";
/* 637 */     if (message != null)
/* 638 */       formatted = message + " ";
/* 639 */     fail(formatted + "expected same:<" + expected + "> was not:<" + actual + ">");
/*     */   }
/*     */   
/*     */ 
/*     */   private static void failNotEquals(String message, Object expected, Object actual)
/*     */   {
/* 645 */     fail(format(message, expected, actual));
/*     */   }
/*     */   
/*     */   static String format(String message, Object expected, Object actual) {
/* 649 */     String formatted = "";
/* 650 */     if ((message != null) && (!message.equals("")))
/* 651 */       formatted = message + " ";
/* 652 */     String expectedString = String.valueOf(expected);
/* 653 */     String actualString = String.valueOf(actual);
/* 654 */     if (expectedString.equals(actualString)) {
/* 655 */       return formatted + "expected: " + formatClassAndValue(expected, expectedString) + " but was: " + formatClassAndValue(actual, actualString);
/*     */     }
/*     */     
/*     */ 
/* 659 */     return formatted + "expected:<" + expectedString + "> but was:<" + actualString + ">";
/*     */   }
/*     */   
/*     */   private static String formatClassAndValue(Object value, String valueString)
/*     */   {
/* 664 */     String className = value == null ? "null" : value.getClass().getName();
/* 665 */     return className + "<" + valueString + ">";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(String message, Object[] expecteds, Object[] actuals)
/*     */   {
/* 688 */     assertArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(Object[] expecteds, Object[] actuals)
/*     */   {
/* 707 */     assertArrayEquals(expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> void assertThat(T actual, Matcher<T> matcher)
/*     */   {
/* 736 */     assertThat("", actual, matcher);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> void assertThat(String reason, T actual, Matcher<T> matcher)
/*     */   {
/* 770 */     if (!matcher.matches(actual)) {
/* 771 */       Description description = new StringDescription();
/* 772 */       description.appendText(reason);
/* 773 */       description.appendText("\nExpected: ");
/* 774 */       description.appendDescriptionOf(matcher);
/* 775 */       description.appendText("\n     got: ");
/* 776 */       description.appendValue(actual);
/* 777 */       description.appendText("\n");
/* 778 */       throw new AssertionError(description.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/Assert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */