/*    */ package org.junit.internal.matchers;
/*    */ 
/*    */ import org.hamcrest.CoreMatchers;
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Matcher;
/*    */ 
/*    */ public class Each
/*    */ {
/*    */   public static <T> Matcher<Iterable<T>> each(final Matcher<T> individual)
/*    */   {
/* 11 */     Matcher<Iterable<T>> allItemsAre = CoreMatchers.not(IsCollectionContaining.hasItem(CoreMatchers.not(individual)));
/*    */     
/* 13 */     new org.hamcrest.BaseMatcher() {
/*    */       public boolean matches(Object item) {
/* 15 */         return this.val$allItemsAre.matches(item);
/*    */       }
/*    */       
/*    */       public void describeTo(Description description) {
/* 19 */         description.appendText("each ");
/* 20 */         individual.describeTo(description);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/matchers/Each.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */