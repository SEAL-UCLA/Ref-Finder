/*    */ package org.junit.internal;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class RealSystem implements JUnitSystem
/*    */ {
/*    */   public void exit(int code) {
/*  8 */     System.exit(code);
/*    */   }
/*    */   
/*    */   public PrintStream out() {
/* 12 */     return System.out;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/RealSystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */