/*    */ package org.junit.internal;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import org.junit.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ComparisonCriteria
/*    */ {
/*    */   public void arrayEquals(String message, Object expecteds, Object actuals)
/*    */     throws ArrayComparisonFailure
/*    */   {
/* 32 */     if (expecteds == actuals)
/* 33 */       return;
/* 34 */     String header = message + ": ";
/*    */     
/* 36 */     int expectedsLength = assertArraysAreSameLength(expecteds, actuals, header);
/*    */     
/*    */ 
/* 39 */     for (int i = 0; i < expectedsLength; i++) {
/* 40 */       Object expected = Array.get(expecteds, i);
/* 41 */       Object actual = Array.get(actuals, i);
/*    */       
/* 43 */       if ((isArray(expected)) && (isArray(actual))) {
/*    */         try {
/* 45 */           arrayEquals(message, expected, actual);
/*    */         } catch (ArrayComparisonFailure e) {
/* 47 */           e.addDimension(i);
/* 48 */           throw e;
/*    */         }
/*    */       } else
/*    */         try {
/* 52 */           assertElementsEqual(expected, actual);
/*    */         } catch (AssertionError e) {
/* 54 */           throw new ArrayComparisonFailure(header, e, i);
/*    */         }
/*    */     }
/*    */   }
/*    */   
/*    */   private boolean isArray(Object expected) {
/* 60 */     return (expected != null) && (expected.getClass().isArray());
/*    */   }
/*    */   
/*    */   private int assertArraysAreSameLength(Object expecteds, Object actuals, String header)
/*    */   {
/* 65 */     if (expecteds == null)
/* 66 */       Assert.fail(header + "expected array was null");
/* 67 */     if (actuals == null)
/* 68 */       Assert.fail(header + "actual array was null");
/* 69 */     int actualsLength = Array.getLength(actuals);
/* 70 */     int expectedsLength = Array.getLength(expecteds);
/* 71 */     if (actualsLength != expectedsLength) {
/* 72 */       Assert.fail(header + "array lengths differed, expected.length=" + expectedsLength + " actual.length=" + actualsLength);
/*    */     }
/* 74 */     return expectedsLength;
/*    */   }
/*    */   
/*    */   protected abstract void assertElementsEqual(Object paramObject1, Object paramObject2);
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/ComparisonCriteria.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */