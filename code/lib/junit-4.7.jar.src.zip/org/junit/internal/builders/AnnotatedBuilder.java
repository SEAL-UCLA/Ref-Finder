/*    */ package org.junit.internal.builders;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.junit.runner.RunWith;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runners.model.InitializationError;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ public class AnnotatedBuilder
/*    */   extends RunnerBuilder
/*    */ {
/*    */   private static final String CONSTRUCTOR_ERROR_FORMAT = "Custom runner class %s should have a public constructor with signature %s(Class testClass)";
/*    */   private RunnerBuilder fSuiteBuilder;
/*    */   
/*    */   public AnnotatedBuilder(RunnerBuilder suiteBuilder)
/*    */   {
/* 17 */     this.fSuiteBuilder = suiteBuilder;
/*    */   }
/*    */   
/*    */   public Runner runnerForClass(Class<?> testClass) throws Exception
/*    */   {
/* 22 */     RunWith annotation = (RunWith)testClass.getAnnotation(RunWith.class);
/* 23 */     if (annotation != null)
/* 24 */       return buildRunner(annotation.value(), testClass);
/* 25 */     return null;
/*    */   }
/*    */   
/*    */   public Runner buildRunner(Class<? extends Runner> runnerClass, Class<?> testClass) throws Exception
/*    */   {
/*    */     try {
/* 31 */       return (Runner)runnerClass.getConstructor(new Class[] { Class.class }).newInstance(new Object[] { testClass });
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/*    */       try {
/* 35 */         return (Runner)runnerClass.getConstructor(new Class[] { Class.class, RunnerBuilder.class }).newInstance(new Object[] { testClass, this.fSuiteBuilder });
/*    */       }
/*    */       catch (NoSuchMethodException e2)
/*    */       {
/* 39 */         String simpleName = runnerClass.getSimpleName();
/* 40 */         throw new InitializationError(String.format("Custom runner class %s should have a public constructor with signature %s(Class testClass)", new Object[] { simpleName, simpleName }));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/builders/AnnotatedBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */