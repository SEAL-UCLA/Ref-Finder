/*    */ package org.junit.internal.builders;
/*    */ 
/*    */ import junit.framework.TestCase;
/*    */ import org.junit.internal.runners.JUnit38ClassRunner;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ public class JUnit3Builder
/*    */   extends RunnerBuilder
/*    */ {
/*    */   public Runner runnerForClass(Class<?> testClass) throws Throwable
/*    */   {
/* 13 */     if (isPre4Test(testClass))
/* 14 */       return new JUnit38ClassRunner(testClass);
/* 15 */     return null;
/*    */   }
/*    */   
/*    */   boolean isPre4Test(Class<?> testClass) {
/* 19 */     return TestCase.class.isAssignableFrom(testClass);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/builders/JUnit3Builder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */