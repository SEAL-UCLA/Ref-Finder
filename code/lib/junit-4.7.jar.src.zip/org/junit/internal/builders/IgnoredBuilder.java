/*    */ package org.junit.internal.builders;
/*    */ 
/*    */ import org.junit.Ignore;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ 
/*    */ public class IgnoredBuilder
/*    */   extends RunnerBuilder
/*    */ {
/*    */   public Runner runnerForClass(Class<?> testClass)
/*    */   {
/* 13 */     if (testClass.getAnnotation(Ignore.class) != null)
/* 14 */       return new IgnoredClassRunner(testClass);
/* 15 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/builders/IgnoredBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */