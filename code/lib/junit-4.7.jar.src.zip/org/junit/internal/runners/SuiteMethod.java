/*    */ package org.junit.internal.runners;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Modifier;
/*    */ import junit.framework.Test;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuiteMethod
/*    */   extends JUnit38ClassRunner
/*    */ {
/*    */   public SuiteMethod(Class<?> klass)
/*    */     throws Throwable
/*    */   {
/* 23 */     super(testFromSuiteMethod(klass));
/*    */   }
/*    */   
/*    */   public static Test testFromSuiteMethod(Class<?> klass) throws Throwable {
/* 27 */     Method suiteMethod = null;
/* 28 */     Test suite = null;
/*    */     try {
/* 30 */       suiteMethod = klass.getMethod("suite", new Class[0]);
/* 31 */       if (!Modifier.isStatic(suiteMethod.getModifiers())) {
/* 32 */         throw new Exception(klass.getName() + ".suite() must be static");
/*    */       }
/* 34 */       suite = (Test)suiteMethod.invoke(null, new Object[0]);
/*    */     } catch (InvocationTargetException e) {
/* 36 */       throw e.getCause();
/*    */     }
/* 38 */     return suite;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/runners/SuiteMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */