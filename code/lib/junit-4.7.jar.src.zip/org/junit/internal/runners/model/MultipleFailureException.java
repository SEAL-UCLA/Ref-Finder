/*    */ package org.junit.internal.runners.model;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class MultipleFailureException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final List<Throwable> fErrors;
/*    */   
/*    */   public MultipleFailureException(List<Throwable> errors) {
/* 11 */     this.fErrors = errors;
/*    */   }
/*    */   
/*    */   public List<Throwable> getFailures() {
/* 15 */     return this.fErrors;
/*    */   }
/*    */   
/*    */   public static void assertEmpty(List<Throwable> errors) throws Throwable {
/* 19 */     if (errors.isEmpty())
/* 20 */       return;
/* 21 */     if (errors.size() == 1)
/* 22 */       throw ((Throwable)errors.get(0));
/* 23 */     throw new MultipleFailureException(errors);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/runners/model/MultipleFailureException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */