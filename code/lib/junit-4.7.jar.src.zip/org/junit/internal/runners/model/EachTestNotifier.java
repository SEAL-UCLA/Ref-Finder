/*    */ package org.junit.internal.runners.model;
/*    */ 
/*    */ import org.junit.internal.AssumptionViolatedException;
/*    */ import org.junit.runner.Description;
/*    */ import org.junit.runner.notification.Failure;
/*    */ import org.junit.runner.notification.RunNotifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EachTestNotifier
/*    */ {
/*    */   private final RunNotifier fNotifier;
/*    */   private final Description fDescription;
/*    */   
/*    */   public EachTestNotifier(RunNotifier notifier, Description description)
/*    */   {
/* 18 */     this.fNotifier = notifier;
/* 19 */     this.fDescription = description;
/*    */   }
/*    */   
/*    */   public void addFailure(Throwable targetException) {
/* 23 */     if ((targetException instanceof MultipleFailureException)) {
/* 24 */       MultipleFailureException mfe = (MultipleFailureException)targetException;
/* 25 */       for (Throwable each : mfe.getFailures())
/* 26 */         addFailure(each);
/* 27 */       return;
/*    */     }
/* 29 */     this.fNotifier.fireTestFailure(new Failure(this.fDescription, targetException));
/*    */   }
/*    */   
/*    */   public void addFailedAssumption(AssumptionViolatedException e) {
/* 33 */     this.fNotifier.fireTestAssumptionFailed(new Failure(this.fDescription, e));
/*    */   }
/*    */   
/*    */   public void fireTestFinished() {
/* 37 */     this.fNotifier.fireTestFinished(this.fDescription);
/*    */   }
/*    */   
/*    */   public void fireTestStarted() {
/* 41 */     this.fNotifier.fireTestStarted(this.fDescription);
/*    */   }
/*    */   
/*    */   public void fireTestIgnored() {
/* 45 */     this.fNotifier.fireTestIgnored(this.fDescription);
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/runners/model/EachTestNotifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */