package org.junit.internal.runners;

@Deprecated
class FailedBefore
  extends Exception
{
  private static final long serialVersionUID = 1L;
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/runners/FailedBefore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */