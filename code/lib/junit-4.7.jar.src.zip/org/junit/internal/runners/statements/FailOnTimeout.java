/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FailOnTimeout
/*    */   extends Statement
/*    */ {
/*    */   private Statement fNext;
/*    */   private final long fTimeout;
/* 13 */   private boolean fFinished = false;
/*    */   
/* 15 */   private Throwable fThrown = null;
/*    */   
/*    */   public FailOnTimeout(Statement next, long timeout) {
/* 18 */     this.fNext = next;
/* 19 */     this.fTimeout = timeout;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Throwable
/*    */   {
/* 24 */     Thread thread = new Thread()
/*    */     {
/*    */       public void run() {
/*    */         try {
/* 28 */           FailOnTimeout.this.fNext.evaluate();
/* 29 */           FailOnTimeout.this.fFinished = true;
/*    */         } catch (Throwable e) {
/* 31 */           FailOnTimeout.this.fThrown = e;
/*    */         }
/*    */       }
/* 34 */     };
/* 35 */     thread.start();
/* 36 */     thread.join(this.fTimeout);
/* 37 */     if (this.fFinished)
/* 38 */       return;
/* 39 */     if (this.fThrown != null)
/* 40 */       throw this.fThrown;
/* 41 */     Exception exception = new Exception(String.format("test timed out after %d milliseconds", new Object[] { Long.valueOf(this.fTimeout) }));
/*    */     
/* 43 */     exception.setStackTrace(thread.getStackTrace());
/* 44 */     throw exception;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/runners/statements/FailOnTimeout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */