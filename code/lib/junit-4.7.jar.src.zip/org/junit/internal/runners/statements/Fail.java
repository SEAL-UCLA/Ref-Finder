/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ public class Fail extends Statement
/*    */ {
/*    */   private final Throwable fError;
/*    */   
/*    */   public Fail(Throwable e) {
/* 10 */     this.fError = e;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Throwable
/*    */   {
/* 15 */     throw this.fError;
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/runners/statements/Fail.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */