/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ public class ExpectException
/*    */   extends Statement
/*    */ {
/*    */   private Statement fNext;
/*    */   private final Class<? extends Throwable> fExpected;
/*    */   
/*    */   public ExpectException(Statement next, Class<? extends Throwable> expected)
/*    */   {
/* 13 */     this.fNext = next;
/* 14 */     this.fExpected = expected;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Exception
/*    */   {
/* 19 */     boolean complete = false;
/*    */     try {
/* 21 */       this.fNext.evaluate();
/* 22 */       complete = true;
/*    */     } catch (Throwable e) {
/* 24 */       if (!this.fExpected.isAssignableFrom(e.getClass())) {
/* 25 */         String message = "Unexpected exception, expected<" + this.fExpected.getName() + "> but was<" + e.getClass().getName() + ">";
/*    */         
/*    */ 
/* 28 */         throw new Exception(message, e);
/*    */       }
/*    */     }
/* 31 */     if (complete) {
/* 32 */       throw new AssertionError("Expected exception: " + this.fExpected.getName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/runners/statements/ExpectException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */