/*    */ package org.junit.internal;
/*    */ 
/*    */ import org.junit.Assert;
/*    */ 
/*    */ public class InexactComparisonCriteria extends ComparisonCriteria {
/*    */   public double fDelta;
/*    */   
/*    */   public InexactComparisonCriteria(double delta) {
/*  9 */     this.fDelta = delta;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void assertElementsEqual(Object expected, Object actual)
/*    */   {
/* 15 */     if ((expected instanceof Double)) {
/* 16 */       Assert.assertEquals(((Double)expected).doubleValue(), ((Double)actual).doubleValue(), this.fDelta);
/*    */     } else {
/* 18 */       Assert.assertEquals(((Float)expected).floatValue(), ((Float)actual).floatValue(), this.fDelta);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/InexactComparisonCriteria.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */