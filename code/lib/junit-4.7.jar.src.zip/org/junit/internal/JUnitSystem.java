package org.junit.internal;

import java.io.PrintStream;

public abstract interface JUnitSystem
{
  public abstract void exit(int paramInt);
  
  public abstract PrintStream out();
}


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/JUnitSystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */