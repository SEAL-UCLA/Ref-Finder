/*    */ package org.junit.internal.requests;
/*    */ 
/*    */ import org.junit.internal.runners.ErrorReportingRunner;
/*    */ import org.junit.runner.Request;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runner.manipulation.Filter;
/*    */ import org.junit.runner.manipulation.NoTestsRemainException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FilterRequest
/*    */   extends Request
/*    */ {
/*    */   private final Request fRequest;
/*    */   private final Filter fFilter;
/*    */   
/*    */   public FilterRequest(Request classRequest, Filter filter)
/*    */   {
/* 26 */     this.fRequest = classRequest;
/* 27 */     this.fFilter = filter;
/*    */   }
/*    */   
/*    */   public Runner getRunner()
/*    */   {
/*    */     try {
/* 33 */       Runner runner = this.fRequest.getRunner();
/* 34 */       this.fFilter.apply(runner);
/* 35 */       return runner;
/*    */     } catch (NoTestsRemainException e) {}
/* 37 */     return new ErrorReportingRunner(Filter.class, new Exception(String.format("No tests found matching %s from %s", tmp46_36)));
/*    */   }
/*    */ }


/* Location:              /Users/UCLAPLSE/Downloads/LSclipse_1.0.4.jar!/lib/junit-4.7.jar!/org/junit/internal/requests/FilterRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */